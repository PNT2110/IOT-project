void angle_mode() {
  PID_Angle(roll_target, pitch_target, yaw_target, angleroll, anglepitch, 0);
  PID_Rate(Desired_RateRoll, Desired_RatePitch, yaw_vel_target, rateroll, ratepitch, rateyaw);

  // PID_Rate(rateroll_target, ratepitch_target, yaw_vel_target, rateroll, ratepitch, rateyaw);

  esc_1=throttle_smoot - INPUTROLL - INPUTPITCH - INPUTYAW;  // CÁI angle_pid này k cần & vì nó chỉ lấy ra để nó tính toán thoi
  esc_2=throttle_smoot + INPUTROLL + INPUTPITCH - INPUTYAW;
  esc_3=throttle_smoot + INPUTROLL - INPUTPITCH + INPUTYAW;
  esc_4=throttle_smoot - INPUTROLL + INPUTPITCH + INPUTYAW;
  limit_value(900, 1600);
 
}

void limit_value(int min, int max){
  if(esc_1<min) esc_1=min;
  if(esc_2<min) esc_2=min;
  if(esc_3<min) esc_3=min;
  if(esc_4<min) esc_4=min;

  if(esc_1>max) esc_1=max;
  if(esc_2>max) esc_2=max;
  if(esc_3>max) esc_3=max;
  if(esc_4>max) esc_4=max;
}

void no_fly() {
  esc_1 = 800;
  esc_2 = 800;
  esc_3 = 800;
  esc_4 = 800;
  status_arm = 0;
}