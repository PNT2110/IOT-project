// --- Khai báo biến cho Target =
float roll_target, pitch_target, yaw_target, yaw_vel_target;

// --- Khai báo biến từ Cảm biến (Góc và Tốc độ góc) ---
float angleroll, anglepitch;
float rateroll, ratepitch, rateyaw;

//- biến dữ liệu thô từ icm---
float RateRoll, RatePitch, RateYaw;
float AngleRoll, AnglePitch, AngleYaw;

// --- Khai báo biến trung gian giữa 3 vòng PID ---
float Desired_RateRoll = 0, Desired_RatePitch = 0 , Desired_RateYaw = 0;

// --- Khai báo biến đầu ra motor ---
float esc_1, esc_2, esc_3, esc_4;

// --- Biến ga và các đầu ra PID ---
float throttle_smoot;

float INPUTROLL = 0;
float INPUTPITCH = 0;
float INPUTYAW = 0;

float Acc_x, Acc_y, Acc_z;
float Acc_x_bu, Acc_y_bu, Acc_z_bu;

int sbus_status;

unsigned long LoopTimer;

//Biến lấy độ cao từ gia tốc**************************************************************//
float AccZInertial;
float volocity_vertical;  

float rateroll_target;
float ratepitch_target;
//**************************************************************//
//khai báo biến cho BMP388------------------

float altitude;
uint32_t raw_press;
uint32_t raw_temp;
float Altitude_barometer;
float VelocityVerticalKalman;
float AltitudeKalman;
float Altitude_kalman; // biến lấy độ cao cuối cùng
float Velocity_kalman;
static unsigned int sbus_ch[17], channel_sbus[17];

#define arm_disarm 5
#define flight_mode 6

#define value_arm 1800
#define value_disarm 1090

#define value_angle_mode 990

int switch_arm_disarm;
int status_arm;


void setup() {
 setup_icm20602();

 setup_sbus();
 setup_motor();

 
//  delay(1000);
//  readsbus();
//  if(ch(6) > 1500){
  // calip_esc();
//  }

}
void loop() {

  icm20602();
  rateroll = get_RateRoll();
  ratepitch = get_RatePitch();
  rateyaw =  get_RateYaw();
  angleroll = get_AngleRoll();
  anglepitch = get_AnglePitch();
  

  

  readsbus();
  read_data_control();
  

  if( sbus_ch[arm_disarm] < value_disarm) {
    switch_arm_disarm = 0;
  } else if ((sbus_ch[arm_disarm] > value_arm) && (sbus_ch[3] < 1050) ) {
    switch_arm_disarm = 1;
  }
  
  if(switch_arm_disarm == 0) {
    status_arm = 0;
    reset_status_flight();
  } else if( switch_arm_disarm == 1) {
    status_arm = 1;
  }

  sbus_status = read_data_control();
 if( status_arm == 1){
    if(!sbus_status) {
    no_fly();
    } else if( sbus_ch[ flight_mode] > value_angle_mode -100 && sbus_ch[ flight_mode] < value_angle_mode + 100 ) {
    angle_mode(); 
  } else { 
    no_fly();
  }
 }
 
  if(ch(3) < 1050) {
  reset_pid();
 }
  

 control_motor( esc_1, esc_2, esc_3, esc_4, status_arm);
 
 
 while (micros() - LoopTimer < 5000);  
  LoopTimer = micros();

  display();
}




