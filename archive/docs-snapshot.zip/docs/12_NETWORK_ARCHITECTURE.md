# SCOPE-00 — Network architecture

```mermaid
flowchart LR
  Client[Phone/laptop] -. joins once .-> AP[Pi onboard AP\nproposed 192.168.4.1/24]
  AP --> PiWeb[Pi web/config]
  Pi[Pi 5] --> AP
  Pi --> STA[USB Wi-Fi STA\nexternal router/hotspot]
  STA -. optional upstream .-> Internet[(Internet)]
  PC[PC server] <-- LAN/VPN/API --> Pi
  Pi --> S1[external_wifi_connected]
  Pi --> S2[internet_reachable]
  Pi --> S3[central_server_reachable]
```

## Addressing policy

`192.168.4.1/24` is a proposal only. At runtime check overlap with upstream networks, then choose a private /24 with DHCP range and reserve the gateway. Do not document a fixed IP/SSID as fact until measured. Prefer `pi5.local` as convenience only; manual IP remains required.

## Reachability semantics

- `external_wifi_connected`: NetworkManager reports USB STA associated and has a usable address.
- `internet_reachable`: application-level probe to an approved endpoint succeeds; DNS-only is insufficient.
- `central_server_reachable`: authenticated health/version handshake with PC succeeds.

These booleans are independent. Internet down does not imply AP/LAN down. PC down does not imply camera/Pi local service down.

## Portal and recovery

Serve config page on AP gateway with a documented manual URL. Captive portal detection varies by OS and must never be a sole access path. Configuration endpoint accepts typed SSID/profile parameters, validates length/encoding, delegates to a constrained NetworkManager adapter, and never executes arbitrary shell text. On failed STA update, keep AP up and preserve previous known-good profile.

## Segmentation

Default AP clients reach only Pi web/config and allowed local services. No admin SSH from AP by default. Upstream forwarding/NAT is disabled unless explicitly required and tested. TLS/device identity protects PC↔Pi even on a shared LAN.
