# IOT PC Server

PC-local control plane for the IOT Drone Station research prototype.

This repository is organized around one canonical PC application:

- `server/` — FastAPI, SQLAlchemy, SQLite and Alembic migrations.
- `frontend/` — React + TypeScript + Vite dashboard.
- `contracts/` — versioned API and device contracts.
- `tests/` — scope and contract tests for the PC application.
- `docs/` — architecture, security, deployment and acceptance records.
- `archive/` — retired Pi/firmware-era material kept only for traceability.

The PC application is local-first and simulation-only. It is not an official
airspace portal, does not issue flight permits, and has no ARM/DISARM or motor
control endpoint.

## Quick start

Requirements: Python 3.12+ and Node.js 20+.

```bash
python -m venv .venv
.venv/bin/python -m pip install -r server/requirements.lock

export SESSION_SECRET="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(32))')"
export COOKIE_SECURE=false
export ALLOWED_ORIGINS=http://127.0.0.1:5173

.venv/bin/alembic -c server/alembic.ini upgrade head
.venv/bin/uvicorn server.app.main:app --host 127.0.0.1 --port 8765
```

In another terminal:

```bash
npm --prefix frontend ci
npm --prefix frontend run dev -- --host 127.0.0.1 --port 5173
```

The Vite development server proxies `/api` to `127.0.0.1:8765`.

## Tests

```bash
.venv/bin/pytest -q tests
npm --prefix frontend run typecheck
npm --prefix frontend run build
```

All test results must be reported with their environment and timestamp. A
historical PASS in `docs/reports/` is not a replacement for a current run.

## Authentication and data policy

Registration uses email verification, TOTP enrollment and recovery codes.
Login uses password, email OTP and TOTP. Development email delivery is an
explicit fake-mail adapter and must not be treated as a production provider.

Map and flight-request data are synthetic. Every workflow result is labelled
`SIMULATED — NOT A FLIGHT PERMIT`. Secrets must remain in environment or an
approved secret store; never commit `.env`, OTPs, TOTP seeds or private keys.

## Deployment boundary

The supported deployment shape is:

```text
Internet / private overlay
        |
   HTTPS reverse proxy
        |
127.0.0.1:8765  PC server
        |
     SQLite
```

Do not expose Uvicorn directly to the Internet. Before public exposure, set a
strong `SESSION_SECRET`, configure a real email provider, configure HTTPS and
firewall rules, verify backups, and run the security tests. A temporary tunnel
is suitable only for bounded testing.

## Updating the PC server

Keep runtime data outside the source tree when possible. On the deployment
host, update the source in `~/iot-pc-server`, run the migrations, then restart
only the PC-server process. Do not overwrite `.env`, `data/`, `server.log` or
the tunnel log during an update.

```bash
cd ~/iot-pc-server
set -a; . ./.env; set +a
~/IOT/.venv/bin/alembic -c server/alembic.ini upgrade head
kill "$(cat server.pid)"
nohup ~/IOT/.venv/bin/python -m uvicorn server.app.main:app \
  --host 127.0.0.1 --port 8765 > server.log 2>&1 &
echo $! > server.pid
curl -fsS http://127.0.0.1:8765/api/v1/health
```

The current public tunnel is temporary and may change URL or disappear after
restart. Use a named, authenticated Cloudflare tunnel or an HTTPS reverse
proxy before treating the service as production infrastructure.

## Scope boundary

Pi networking, Pi web, GNSS and archived ESP32 firmware are not part of the
PC server runtime. They are documented or archived separately and must not be
silently reintroduced into the PC authorization path.

See `docs/` for the detailed architecture and current gate reports.
