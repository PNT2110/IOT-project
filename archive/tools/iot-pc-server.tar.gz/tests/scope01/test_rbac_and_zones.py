from __future__ import annotations


def test_guest_cannot_read_internal_map(app):
    _, client = app
    response = client.get("/api/v1/internal/zones")
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "AUTH_REQUIRED"


def test_admin_can_crud_with_version_guard_and_audit(app, admin_token):
    application, client = app
    headers = {"Authorization": f"Bearer {admin_token}"}
    internal = client.get("/api/v1/internal/zones", headers=headers)
    assert internal.status_code == 200
    source_id = internal.json()["data"]["items"][0]["source_id"]
    geometry = {"type": "Polygon", "coordinates": [[[30, 30], [30.1, 30], [30.1, 30.1], [30, 30.1], [30, 30]]]}
    created = client.post("/api/v1/internal/zones", headers=headers, json={"name": "New synthetic zone", "geometry": geometry, "visibility": "INTERNAL", "classification": "INTERNAL_RESEARCH", "source_id": source_id})
    assert created.status_code == 201
    zone_id = created.json()["data"]["id"]
    stale = client.patch(f"/api/v1/internal/zones/{zone_id}", headers={**headers, "If-Match": "99"}, json={"name": "Changed", "geometry": geometry, "visibility": "INTERNAL", "classification": "INTERNAL_RESEARCH", "source_id": source_id, "version": 99})
    assert stale.status_code == 409
    updated = client.patch(f"/api/v1/internal/zones/{zone_id}", headers={**headers, "If-Match": "1"}, json={"name": "Changed", "geometry": geometry, "visibility": "INTERNAL", "classification": "INTERNAL_RESEARCH", "source_id": source_id, "version": 1})
    assert updated.status_code == 200
    deleted = client.delete(f"/api/v1/internal/zones/{zone_id}", headers={**headers, "If-Match": "2"})
    assert deleted.status_code == 200
    with application.state.session_factory() as db:
        from server.app.models import AuditEvent
        assert len(db.query(AuditEvent).filter(AuditEvent.object_id == zone_id).all()) == 3


def test_invalid_geometry_is_rejected(app, admin_token):
    _, client = app
    headers = {"Authorization": f"Bearer {admin_token}"}
    response = client.post("/api/v1/internal/zones", headers=headers, json={"name": "Bad", "geometry": {"type": "Point", "coordinates": [0, 0]}, "visibility": "INTERNAL", "classification": "INTERNAL_RESEARCH", "source_id": "00000000-0000-4000-8000-000000000001"})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "INVALID_GEOMETRY"


def test_unknown_zone_does_not_leak_object_details(app, admin_token):
    _, client = app
    headers = {"Authorization": f"Bearer {admin_token}"}
    unknown = "00000000-0000-4000-8000-000000000099"
    response = client.patch(f"/api/v1/internal/zones/{unknown}", headers={**headers, "If-Match": "1"}, json={"name": "Unknown", "geometry": {"type": "Polygon", "coordinates": [[[30, 30], [30.1, 30], [30.1, 30.1], [30, 30.1], [30, 30]]]}, "visibility": "INTERNAL", "classification": "INTERNAL_RESEARCH", "source_id": "00000000-0000-4000-8000-000000000001", "version": 1})
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "NOT_FOUND"


def test_pending_user_cannot_mutate_internal_map(app):
    application, client = app
    password = "P" + __import__("secrets").token_urlsafe(18)
    registration = client.post("/api/v1/auth/register", json={"display_name": "Pending Map User", "email": "pending-map@sample.com", "password": password, "password_confirm": password, "terms_version": "terms-v1"})
    mail = application.state.fake_mail.latest("pending-map@sample.com", "VERIFY_EMAIL")
    enrollment = client.post("/api/v1/auth/verify-email", json={"challenge_id": registration.json()["data"]["challenge_id"], "code": mail.code}).json()["data"]["enrollment_token"]
    secret = client.post("/api/v1/auth/mfa/enroll", headers={"Authorization": f"Bearer {enrollment}"}).json()["data"]["secret"]
    client.post("/api/v1/auth/mfa/confirm", headers={"Authorization": f"Bearer {enrollment}"}, json={"code": __import__("pyotp").TOTP(secret).now()})
    response = client.get("/api/v1/internal/zones")
    assert response.status_code == 403
    assert response.json()["error"]["code"] == "FORBIDDEN"
