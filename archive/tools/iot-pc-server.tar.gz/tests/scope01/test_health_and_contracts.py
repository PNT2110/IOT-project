from __future__ import annotations


def test_health_is_local_and_enveloped(app):
    _, client = app
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    body = response.json()
    assert body["schema_version"] == "v1"
    assert body["data"] == {"status": "ok", "environment": "test", "local_only": True}
    assert response.headers["x-request-id"] == body["request_id"]


def test_public_api_does_not_expose_internal_fixture(app):
    _, client = app
    response = client.get("/api/v1/public/zones")
    assert response.status_code == 200
    body = response.json()
    assert body["data"]["label"].startswith("SIMULATED")
    assert len(body["data"]["items"]) == 1
    assert all(item["visibility"] == "PUBLIC" for item in body["data"]["items"])
    assert all("source_id" not in item for item in body["data"]["items"])


def test_pi_contract_is_read_only_and_has_no_control_routes_in_openapi(app):
    application, _ = app
    paths = set(application.openapi()["paths"])
    assert "/api/v1/pi/v1/map" in paths
    assert "/api/v1/pi/v1/status" in paths
    assert not any(token in path.lower() for path in paths for token in ("arm", "disarm", "flight-permit"))
