from __future__ import annotations

import argparse
import json
import pyotp
import time
import secrets
from datetime import timedelta

from sqlalchemy import select

from server.cli import bootstrap_owner
from server.app.models import EmailChallenge, SessionRecord, User
from server.app.security import digest_token, new_token, utcnow


def test_registration_email_totp_and_login_chain(app):
    application, client = app
    password = "P" + secrets.token_urlsafe(18)
    registration = client.post("/api/v1/auth/register", json={"display_name": "Test User", "email": "test@sample.com", "password": password, "password_confirm": password, "terms_version": "terms-v1"})
    assert registration.status_code == 201
    challenge_id = registration.json()["data"]["challenge_id"]
    mail = application.state.fake_mail.latest("test@sample.com", "VERIFY_EMAIL")
    assert mail is not None

    verified = client.post("/api/v1/auth/verify-email", json={"challenge_id": challenge_id, "code": mail.code})
    assert verified.status_code == 200
    enrollment_token = verified.json()["data"]["enrollment_token"]
    enrolled = client.post("/api/v1/auth/mfa/enroll", headers={"Authorization": f"Bearer {enrollment_token}"})
    assert enrolled.status_code == 200
    secret = enrolled.json()["data"]["secret"]
    confirmed = client.post("/api/v1/auth/mfa/confirm", headers={"Authorization": f"Bearer {enrollment_token}"}, json={"code": pyotp.TOTP(secret).now()})
    assert confirmed.status_code == 200
    assert len(confirmed.json()["data"]["recovery_codes"]) == 8
    assert "session" in confirmed.cookies
    assert "HttpOnly" in confirmed.headers["set-cookie"]
    assert "Secure" not in confirmed.headers["set-cookie"]  # isolated TestClient uses HTTP
    assert "SameSite=lax" in confirmed.headers["set-cookie"]
    csrf_blocked = client.post("/api/v1/auth/logout")
    assert csrf_blocked.status_code == 403
    assert csrf_blocked.json()["error"]["code"] == "CSRF_REQUIRED"

    login = client.post("/api/v1/auth/login", json={"email": "test@sample.com", "password": password, "terms_version": "terms-v1"})
    assert login.status_code == 200
    login_token = login.json()["data"]["login_token"]
    login_challenge = login.json()["data"]["challenge_id"]
    login_mail = application.state.fake_mail.latest("test@sample.com", "LOGIN_OTP")
    assert login_mail is not None
    otp = client.post("/api/v1/auth/verify-login-otp", headers={"Authorization": f"Bearer {login_token}"}, json={"challenge_id": login_challenge, "code": login_mail.code})
    assert otp.status_code == 200
    next_step_code = pyotp.TOTP(secret).at((int(time.time()) // 30 + 1) * 30)
    totp = client.post("/api/v1/auth/verify-totp", headers={"Authorization": f"Bearer {login_token}"}, json={"code": next_step_code})
    assert totp.status_code == 200
    access_token = totp.json()["data"]["access_token"]
    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {access_token}"})
    assert me.status_code == 200
    assert me.json()["data"]["status"] == "PENDING"
    assert me.json()["data"]["role"] == "GUEST"


def test_email_challenge_replay_and_attempt_limit_are_enforced(app):
    application, client = app
    password = "P" + secrets.token_urlsafe(18)
    registration = client.post("/api/v1/auth/register", json={"display_name": "Challenge User", "email": "challenge@sample.com", "password": password, "password_confirm": password, "terms_version": "terms-v1"})
    challenge_id = registration.json()["data"]["challenge_id"]
    mail = application.state.fake_mail.latest("challenge@sample.com", "VERIFY_EMAIL")
    assert mail is not None
    verified = client.post("/api/v1/auth/verify-email", json={"challenge_id": challenge_id, "code": mail.code})
    assert verified.status_code == 200
    replay = client.post("/api/v1/auth/verify-email", json={"challenge_id": challenge_id, "code": mail.code})
    assert replay.status_code == 400
    assert replay.json()["error"]["code"] == "CHALLENGE_INVALID"

    second = client.post("/api/v1/auth/register", json={"display_name": "Attempt User", "email": "attempt@sample.com", "password": password, "password_confirm": password, "terms_version": "terms-v1"})
    second_id = second.json()["data"]["challenge_id"]
    second_mail = application.state.fake_mail.latest("attempt@sample.com", "VERIFY_EMAIL")
    wrong = "000000" if second_mail.code != "000000" else "999999"
    for _ in range(5):
        failed = client.post("/api/v1/auth/verify-email", json={"challenge_id": second_id, "code": wrong})
        assert failed.status_code == 400
        assert failed.json()["error"]["code"] == "CODE_INVALID"
    limited = client.post("/api/v1/auth/verify-email", json={"challenge_id": second_id, "code": second_mail.code})
    assert limited.status_code == 400
    assert limited.json()["error"]["code"] == "CHALLENGE_INVALID"
    with application.state.session_factory() as db:
        challenge = db.get(EmailChallenge, second_id)
        assert challenge.attempts == 5


def test_invalid_totp_does_not_complete_auth(app):
    application, client = app
    password = "P" + secrets.token_urlsafe(18)
    registration = client.post("/api/v1/auth/register", json={"display_name": "Replay User", "email": "replay@sample.com", "password": password, "password_confirm": password, "terms_version": "terms-v1"})
    challenge_id = registration.json()["data"]["challenge_id"]
    mail = application.state.fake_mail.latest("replay@sample.com", "VERIFY_EMAIL")
    enrollment = client.post("/api/v1/auth/verify-email", json={"challenge_id": challenge_id, "code": mail.code}).json()["data"]["enrollment_token"]
    enrolled = client.post("/api/v1/auth/mfa/enroll", headers={"Authorization": f"Bearer {enrollment}"}).json()["data"]
    bad_code = "000000" if pyotp.TOTP(enrolled["secret"]).now() != "000000" else "999999"
    bad = client.post("/api/v1/auth/mfa/confirm", headers={"Authorization": f"Bearer {enrollment}"}, json={"code": bad_code})
    assert bad.status_code == 400
    assert bad.json()["error"]["code"] == "TOTP_INVALID"
    assert enrolled["secret"]
    for _ in range(4):
        assert client.post("/api/v1/auth/mfa/confirm", headers={"Authorization": f"Bearer {enrollment}"}, json={"code": bad_code}).status_code == 400
    limited = client.post("/api/v1/auth/mfa/confirm", headers={"Authorization": f"Bearer {enrollment}"}, json={"code": bad_code})
    assert limited.status_code == 429
    assert limited.json()["error"]["code"] == "FACTOR_RATE_LIMITED"


def test_owner_bootstrap_has_a_complete_local_email_mfa_path(app, tmp_path, monkeypatch):
    application, client = app
    outbox = tmp_path / "owner-mail.jsonl"
    monkeypatch.setenv("SESSION_SECRET", application.state.settings.session_secret)
    monkeypatch.setenv("DATABASE_URL", application.state.settings.database_url)
    monkeypatch.setenv("FAKE_MAIL_OUTBOX", str(outbox))
    answers = iter(["OwnerPassword-12345", "OwnerPassword-12345"])
    monkeypatch.setattr("server.cli.getpass.getpass", lambda _prompt: next(answers))
    assert bootstrap_owner(argparse.Namespace(name="Local Owner", email="owner@sample.com")) == 0
    messages = [json.loads(line) for line in outbox.read_text(encoding="utf-8").splitlines()]
    verification = messages[-1]
    assert verification["purpose"] == "VERIFY_EMAIL"
    with application.state.session_factory() as db:
        owner = db.scalar(select(User).where(User.email_normalized == "owner@sample.com"))
        challenge = db.scalar(select(EmailChallenge).where(EmailChallenge.user_id == owner.id))
        assert owner.status == "PENDING"
        assert owner.role == "OWNER"
        assert owner.email_verified_at is None
        assert challenge.id
    verified = client.post("/api/v1/auth/verify-email", json={"challenge_id": challenge.id, "code": verification["code"]})
    enrollment = verified.json()["data"]["enrollment_token"]
    secret = client.post("/api/v1/auth/mfa/enroll", headers={"Authorization": f"Bearer {enrollment}"}).json()["data"]["secret"]
    completed = client.post("/api/v1/auth/mfa/confirm", headers={"Authorization": f"Bearer {enrollment}"}, json={"code": pyotp.TOTP(secret).now()})
    assert completed.status_code == 200
    assert completed.json()["data"]["role"] == "OWNER"
    me = client.get("/api/v1/auth/me")
    assert me.status_code == 200
    assert me.json()["data"]["status"] == "PENDING"


def test_expired_session_is_rejected(app, admin_token):
    application, client = app
    expired_token = new_token()
    with application.state.session_factory() as db:
        admin = db.scalar(select(User).where(User.role == "ADMIN"))
        now = utcnow()
        db.add(SessionRecord(token_digest=digest_token(application.state.settings.session_secret, expired_token), user_id=admin.id, stage="AUTHENTICATED", csrf_digest=digest_token(application.state.settings.session_secret, "expired-csrf"), expires_at=now - timedelta(minutes=1), last_seen_at=now, created_at=now))
        db.commit()
    response = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {expired_token}"})
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "SESSION_INVALID"
