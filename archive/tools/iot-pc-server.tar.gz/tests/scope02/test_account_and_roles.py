from __future__ import annotations

from sqlalchemy import select

from server.app.models import AuditEvent, SessionRecord, User, WorkflowHistory


def auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def test_account_review_policy_status_version_and_session_revoke(app, actors):
    application, client = app
    owner = auth(actors["owner"]["token"])
    admin = auth(actors["admin"]["token"])
    operator = auth(actors["operator"]["token"])
    target = actors["other"]

    assert client.get("/api/v1/account-review/users", headers=operator).status_code == 403
    assert client.get("/api/v1/account-review/users", headers=admin).status_code == 200
    self_review = client.post(f"/api/v1/account-review/users/{actors['owner']['id']}/status", headers={**owner, "If-Match": "1", "Idempotency-Key": "self-account"}, json={"status": "SUSPENDED", "reason": "self test"})
    assert self_review.status_code == 403

    changed = client.post(f"/api/v1/account-review/users/{target['id']}/status", headers={**owner, "If-Match": "1", "Idempotency-Key": "account-suspend-1"}, json={"status": "SUSPENDED", "reason": "review hold"})
    assert changed.status_code == 200
    assert changed.json()["data"]["account"]["status"] == "SUSPENDED"
    replay = client.post(f"/api/v1/account-review/users/{target['id']}/status", headers={**owner, "If-Match": "1", "Idempotency-Key": "account-suspend-1"}, json={"status": "SUSPENDED", "reason": "review hold"})
    assert replay.status_code == 200
    assert replay.json()["data"]["account"]["version"] == changed.json()["data"]["account"]["version"]
    assert client.get("/api/v1/auth/me", headers=auth(target["token"])).status_code == 401
    stale = client.post(f"/api/v1/account-review/users/{target['id']}/status", headers={**owner, "If-Match": "1", "Idempotency-Key": "account-suspend-2"}, json={"status": "ACTIVE", "reason": "stale"})
    assert stale.status_code == 409

    with application.state.session_factory() as db:
        assert db.scalar(select(User).where(User.id == target["id"])).status == "SUSPENDED"
        assert db.scalar(select(SessionRecord).where(SessionRecord.token_digest == __import__("server.app.security", fromlist=["digest_token"]).digest_token(application.state.settings.session_secret, target["token"]))).revoked_at is not None
        assert db.scalar(select(WorkflowHistory).where(WorkflowHistory.object_type == "USER", WorkflowHistory.object_id == target["id"])) is not None
        assert db.scalar(select(AuditEvent).where(AuditEvent.object_type == "USER", AuditEvent.object_id == target["id"])) is not None


def test_role_elevation_owner_review_duplicate_and_key_reuse(app, actors):
    _, client = app
    guest = auth(actors["guest"]["token"])
    owner = auth(actors["owner"]["token"])
    created = client.post("/api/v1/role-elevations", headers={**guest, "Idempotency-Key": "role-1"}, json={"requested_role": "ADMIN", "reason": "Need review access"})
    assert created.status_code == 200
    item = created.json()["data"]
    duplicate = client.post("/api/v1/role-elevations", headers={**guest, "Idempotency-Key": "role-1"}, json={"requested_role": "ADMIN", "reason": "Need review access"})
    assert duplicate.status_code == 200
    assert duplicate.json()["data"]["id"] == item["id"]
    mismatch = client.post("/api/v1/role-elevations", headers={**guest, "Idempotency-Key": "role-1"}, json={"requested_role": "OPERATOR", "reason": "Different"})
    assert mismatch.status_code == 409
    review = client.get("/api/v1/role-elevations/review", headers=owner)
    assert review.status_code == 200
    decided = client.post(f"/api/v1/role-elevations/{item['id']}/decision", headers={**owner, "If-Match": "1", "Idempotency-Key": "role-decision-1"}, json={"decision": "APPROVED", "reason": "Owner approved"})
    assert decided.status_code == 200
    assert client.get("/api/v1/role-elevations", headers=guest).status_code == 200
    with client.app.state.session_factory() as db:
        assert db.scalar(select(User).where(User.id == actors["guest"]["id"])).role == "ADMIN"


def test_pending_account_cannot_request_role_or_workflow(app, actors):
    application, client = app
    with application.state.session_factory() as db:
        user = db.get(User, actors["guest"]["id"])
        user.status = "PENDING"
        user.version += 1
        db.commit()
    response = client.post("/api/v1/role-elevations", headers={**auth(actors["guest"]["token"]), "Idempotency-Key": "pending-role"}, json={"requested_role": "ADMIN", "reason": "Should be blocked"})
    assert response.status_code == 403
