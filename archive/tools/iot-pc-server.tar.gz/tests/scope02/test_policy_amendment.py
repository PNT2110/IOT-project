from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select

from server.app.models import AuditEvent, CapabilityGrant, Credential, RoleElevationRequest, User, WorkflowHistory
from server.app.security import hash_password, utcnow


def auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def test_admin_requires_owner_grant_and_grant_scope_is_enforced(app, actors):
    application, client = app
    owner = auth(actors["owner"]["token"])
    admin = auth(actors["admin"]["token"])
    operator = auth(actors["operator"]["token"])
    with application.state.session_factory() as db:
        pending = User(display_name="Pending ordinary", email_normalized="pending-ordinary@sample.com", status="PENDING", role="GUEST", version=1, email_verified_at=utcnow(), created_at=utcnow(), updated_at=utcnow())
        pending.credential = Credential(password_hash=hash_password("not-used-in-test"), totp_active=True, created_at=utcnow(), updated_at=utcnow())
        db.add(pending)
        db.flush()
        pending_id = pending.id
        db.commit()

    denied = client.post(f"/api/v1/account-review/users/{pending_id}/status", headers={**admin, "If-Match": "1", "Idempotency-Key": "admin-no-grant"}, json={"status": "ACTIVE", "reason": "Should be denied"})
    assert denied.status_code == 403
    assert client.post("/api/v1/account-review/grants", headers={**admin, "Idempotency-Key": "admin-cannot-grant"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ACCOUNT_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Self grant"}).status_code == 403
    assert client.post("/api/v1/account-review/grants", headers={**operator, "Idempotency-Key": "operator-cannot-grant"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ACCOUNT_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Operator grant"}).status_code == 403

    granted = client.post("/api/v1/account-review/grants", headers={**owner, "Idempotency-Key": "grant-admin-1"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ACCOUNT_APPROVE", "ADMIN_ROLE_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Explicit owner delegation"})
    assert granted.status_code == 201
    grant = granted.json()["data"]
    replay = client.post("/api/v1/account-review/grants", headers={**owner, "Idempotency-Key": "grant-admin-1"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ACCOUNT_APPROVE", "ADMIN_ROLE_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Explicit owner delegation"})
    assert replay.status_code == 201
    approved = client.post(f"/api/v1/account-review/users/{pending_id}/status", headers={**admin, "If-Match": "1", "Idempotency-Key": "admin-approve-1"}, json={"status": "ACTIVE", "reason": "Within owner grant"})
    assert approved.status_code == 200
    out_of_scope = client.post(f"/api/v1/account-review/users/{actors['other']['id']}/status", headers={**admin, "If-Match": "1", "Idempotency-Key": "admin-suspend-1"}, json={"status": "SUSPENDED", "reason": "Not delegated"})
    assert out_of_scope.status_code == 403

    revoked = client.post(f"/api/v1/account-review/grants/{grant['id']}/revoke", headers={**owner, "If-Match": "1", "Idempotency-Key": "revoke-grant-1"}, json={"reason": "Delegation ended"})
    assert revoked.status_code == 200
    after_revoke = client.post(f"/api/v1/account-review/users/{actors['other']['id']}/status", headers={**admin, "If-Match": "1", "Idempotency-Key": "admin-after-revoke"}, json={"status": "SUSPENDED", "reason": "Should be denied"})
    assert after_revoke.status_code == 403
    with application.state.session_factory() as db:
        row = db.scalar(select(CapabilityGrant).where(CapabilityGrant.id == grant["id"]))
        assert row.revoked_at is not None
        assert db.scalar(select(AuditEvent).where(AuditEvent.object_type == "CAPABILITY_GRANT", AuditEvent.object_id == grant["id"], AuditEvent.action == "CAPABILITY_GRANT_REVOKE")) is not None
        assert db.scalar(select(WorkflowHistory).where(WorkflowHistory.object_type == "CAPABILITY_GRANT", WorkflowHistory.object_id == grant["id"], WorkflowHistory.action == "REVOKE")) is not None


def test_granted_admin_can_only_approve_guest_to_admin(app, actors):
    application, client = app
    owner = auth(actors["owner"]["token"])
    admin = auth(actors["admin"]["token"])
    other = auth(actors["other"]["token"])
    grant = client.post("/api/v1/account-review/grants", headers={**owner, "Idempotency-Key": "grant-role-1"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ADMIN_ROLE_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Admin role review"})
    assert grant.status_code == 201
    created = client.post("/api/v1/role-elevations", headers={**other, "Idempotency-Key": "other-role-request"}, json={"requested_role": "ADMIN", "reason": "Need admin"})
    assert created.status_code == 200
    item = created.json()["data"]
    assert client.get("/api/v1/role-elevations/review", headers=admin).status_code == 200
    decided = client.post(f"/api/v1/role-elevations/{item['id']}/decision", headers={**admin, "If-Match": "1", "Idempotency-Key": "admin-role-decision"}, json={"decision": "APPROVED", "reason": "Within owner grant"})
    assert decided.status_code == 200
    with application.state.session_factory() as db:
        assert db.scalar(select(User).where(User.id == actors["other"]["id"])).role == "ADMIN"
    with application.state.session_factory() as db:
        db.get(User, actors["other"]["id"]).role = "OPERATOR"
        db.commit()
    operator_request = client.post("/api/v1/role-elevations", headers={**other, "Idempotency-Key": "operator-role-request"}, json={"requested_role": "ADMIN", "reason": "Need admin again"})
    assert operator_request.status_code == 200
    second = operator_request.json()["data"]
    listed_for_granted_admin = client.get("/api/v1/role-elevations/review", headers=admin)
    assert listed_for_granted_admin.status_code == 200
    assert second["id"] not in {item["id"] for item in listed_for_granted_admin.json()["data"]["items"]}
    denied = client.post(f"/api/v1/role-elevations/{second['id']}/decision", headers={**admin, "If-Match": "1", "Idempotency-Key": "admin-role-deny-scope"}, json={"decision": "REJECTED", "reason": "Admin grant only approves ADMIN"})
    assert denied.status_code == 403


def test_capability_revoke_is_immediate_and_stale_version_is_safe(app, actors):
    _, client = app
    owner = auth(actors["owner"]["token"])
    grant = client.post("/api/v1/account-review/grants", headers={**owner, "Idempotency-Key": "grant-stale-1"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ACCOUNT_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Stale test"}).json()["data"]
    stale = client.post(f"/api/v1/account-review/grants/{grant['id']}/revoke", headers={**owner, "If-Match": "99", "Idempotency-Key": "revoke-stale"}, json={"reason": "Stale"})
    assert stale.status_code == 409
    revoked = client.post(f"/api/v1/account-review/grants/{grant['id']}/revoke", headers={**owner, "If-Match": "1", "Idempotency-Key": "revoke-good"}, json={"reason": "Valid revoke"})
    assert revoked.status_code == 200


def test_review_responses_expose_effective_scope_and_not_owner_only(app, actors):
    _, client = app
    owner = auth(actors["owner"]["token"])
    admin = auth(actors["admin"]["token"])

    no_grant = client.get("/api/v1/account-review/capabilities", headers=admin)
    assert no_grant.status_code == 200
    assert no_grant.json()["data"] == {
        "policy": "OWNER_OR_GRANTED_ADMIN_SCOPED",
        "role": "ADMIN",
        "status": "ACTIVE",
        "can_approve_accounts": False,
        "can_approve_admin_role": False,
        "account_approve": {"allowed": False, "scope": "NONE"},
        "admin_role_approve": {"allowed": False, "scope": "NONE"},
    }
    assert client.get("/api/v1/role-elevations/review", headers=admin).status_code == 403
    owner_role_review = client.get("/api/v1/role-elevations/review", headers=owner)
    assert owner_role_review.status_code == 200
    assert owner_role_review.json()["data"]["policy"] == "OWNER_OR_GRANTED_ADMIN_SCOPED"
    assert owner_role_review.json()["data"]["effective_capabilities"]["admin_role_approve"]["scope"] == "ALL_ROLE_ELEVATIONS_EXCEPT_SELF"

    owner_capabilities = client.get("/api/v1/account-review/capabilities", headers=owner)
    assert owner_capabilities.status_code == 200
    assert owner_capabilities.json()["data"]["account_approve"]["scope"] == "ALL_ACCOUNT_STATUS_TRANSITIONS_EXCEPT_SELF"
    assert owner_capabilities.json()["data"]["admin_role_approve"]["scope"] == "ALL_ROLE_ELEVATIONS_EXCEPT_SELF"
    owner_accounts = client.get("/api/v1/account-review/users", headers=owner)
    assert owner_accounts.status_code == 200
    assert owner_accounts.json()["data"]["role_policy"] == "OWNER_OR_GRANTED_ADMIN_SCOPED"

    granted = client.post("/api/v1/account-review/grants", headers={**owner, "Idempotency-Key": "representation-grant"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ACCOUNT_APPROVE", "ADMIN_ROLE_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Representation test"})
    assert granted.status_code == 201
    granted_capabilities = client.get("/api/v1/account-review/capabilities", headers=admin)
    assert granted_capabilities.status_code == 200
    assert granted_capabilities.json()["data"]["account_approve"]["scope"] == "PENDING_PC_GUEST_TO_ACTIVE"
    assert granted_capabilities.json()["data"]["admin_role_approve"]["scope"] == "ACTIVE_PC_GUEST_TO_ADMIN_APPROVE_ONLY"
    admin_accounts = client.get("/api/v1/account-review/users", headers=admin)
    assert admin_accounts.status_code == 200
    assert admin_accounts.json()["data"]["effective_capabilities"]["account_approve"]["scope"] == "PENDING_PC_GUEST_TO_ACTIVE"
    admin_detail = client.get(f"/api/v1/account-review/users/{actors['other']['id']}", headers=admin)
    assert admin_detail.status_code == 200
    assert admin_detail.json()["data"]["effective_capabilities"]["account_approve"]["scope"] == "PENDING_PC_GUEST_TO_ACTIVE"

    role_review = client.get("/api/v1/role-elevations/review", headers=admin)
    assert role_review.status_code == 200
    role_data = role_review.json()["data"]
    assert role_data["policy"] == "OWNER_OR_GRANTED_ADMIN_SCOPED"
    assert role_data["effective_capabilities"]["admin_role_approve"]["scope"] == "ACTIVE_PC_GUEST_TO_ADMIN_APPROVE_ONLY"
    assert "OWNER_ONLY_REVIEW" not in str(role_data)


def test_role_self_review_and_owner_elevation_are_rejected_without_side_effect(app, actors):
    application, client = app
    owner = auth(actors["owner"]["token"])
    admin = auth(actors["admin"]["token"])
    invalid_owner_request = client.post("/api/v1/role-elevations", headers={**auth(actors["guest"]["token"]), "Idempotency-Key": "owner-role-invalid"}, json={"requested_role": "OWNER", "reason": "Must be rejected"})
    assert invalid_owner_request.status_code == 422

    grant = client.post("/api/v1/account-review/grants", headers={**owner, "Idempotency-Key": "self-review-grant"}, json={"grantee_user_id": actors["admin"]["id"], "actions": ["ADMIN_ROLE_APPROVE"], "resource_scope": "PC_GUEST", "reason": "Self review test"})
    assert grant.status_code == 201
    now = utcnow()
    with application.state.session_factory() as db:
        item = RoleElevationRequest(requester_user_id=actors["admin"]["id"], requested_role="ADMIN", status="PENDING", reason="Synthetic self-review", version=1, created_at=now, updated_at=now)
        db.add(item)
        db.commit()
        request_id = item.id
    response = client.post(f"/api/v1/role-elevations/{request_id}/decision", headers={**admin, "If-Match": "1", "Idempotency-Key": "self-review-decision"}, json={"decision": "APPROVED", "reason": "Must be denied"})
    assert response.status_code == 403
    with application.state.session_factory() as db:
        item = db.get(RoleElevationRequest, request_id)
        assert item.status == "PENDING"
        assert item.reviewer_user_id is None
