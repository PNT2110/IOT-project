export interface LoginResponse {
  username: string;
  role: string;
  csrf_token: string;
}

export interface User {
  username: string;
  role: string;
}

export interface GpsFix {
  latitude: number;
  longitude: number;
  altitude_m: number;
  speed_mps: number;
  course_deg: number;
  satellites: number;
  hdop: number;
  fix_quality: number;
  valid: boolean;
  stale: boolean;
  raw: string;
}

export interface Attitude {
  roll: number;
  pitch: number;
  yaw: number;
}

export interface PidAxis {
  kp: number;
  ki: number;
  kd: number;
  setpoint: number;
  measured: number;
  output: number;
}

export interface PidState {
  roll: PidAxis;
  pitch: PidAxis;
  yaw: PidAxis;
}

export interface GeofenceState {
  status: "unknown" | "safe" | "warning" | "breach";
  zone_id: string | null;
  zone_name: string | null;
  distance_m: number | null;
  data_ready: boolean;
  checked_at: number;
}

export interface TelemetryFrame {
  timestamp: number;
  gps: GpsFix;
  attitude: Attitude;
  pid: PidState;
  armed: boolean;
  flight_mode: string;
  esp_connected: boolean;
  gps_connected: boolean;
  geofence: GeofenceState;
}

export interface SystemStatus {
  gps_connected: boolean;
  esp_connected: boolean;
  geofence_ready: boolean;
  map_ready: boolean;
  real_commands_enabled: boolean;
  raw_esp_lines: number;
  gps_port: string;
  esp_port: string;
}

export interface MapPackStatus {
  available: boolean;
  size_bytes?: number;
}

export interface CameraStatus {
  status: string;
}

export interface FlightHistory {
  id: string;
  start_time: string;
  end_time?: string;
}

export interface PreflightStatus {
  passed: boolean;
  checks: Record<string, boolean>;
}

export const apiClient = {
  async login(username: string, password: string, totp?: string): Promise<LoginResponse> {
    const res = await fetch("/api/v1/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, totp }),
    });
    if (!res.ok) throw new Error("Login failed");
    return res.json();
  },

  async logout(csrfToken: string): Promise<void> {
    const res = await fetch("/api/v1/auth/logout", {
      method: "POST",
      headers: { "X-CSRF-Token": csrfToken },
    });
    if (!res.ok) throw new Error("Logout failed");
  },

  async getMe(): Promise<User> {
    const res = await fetch("/api/v1/auth/me");
    if (!res.ok) throw new Error("Not authenticated");
    return res.json();
  },

  async getHealth(): Promise<{ status: string }> {
    const res = await fetch("/api/v1/health");
    if (!res.ok) throw new Error("Health check failed");
    return res.json();
  },

  async getStatus(): Promise<SystemStatus> {
    const res = await fetch("/api/v1/status");
    if (!res.ok) throw new Error("Failed to get status");
    return res.json();
  },

  async getLatestTelemetry(): Promise<TelemetryFrame> {
    const res = await fetch("/api/v1/telemetry/latest");
    if (!res.ok) throw new Error("Failed to get telemetry");
    return res.json();
  },

  async getRawSerial(): Promise<string[]> {
    const res = await fetch("/api/v1/serial/raw");
    if (!res.ok) throw new Error("Failed to get raw serial");
    return res.json();
  },

  async getPreflight(): Promise<PreflightStatus> {
    const res = await fetch("/api/v1/preflight");
    if (!res.ok) throw new Error("Failed to get preflight status");
    return res.json();
  },

  async getGeofenceZones(): Promise<any> {
    const res = await fetch("/api/v1/geofence/zones");
    if (!res.ok) throw new Error("Failed to get geofence zones");
    return res.json();
  },

  async syncGeofence(csrfToken: string): Promise<void> {
    const res = await fetch("/api/v1/geofence/sync", {
      method: "POST",
      headers: { "X-CSRF-Token": csrfToken },
    });
    if (!res.ok) throw new Error("Failed to sync geofence");
  },

  async getMapPackStatus(): Promise<MapPackStatus> {
    const res = await fetch("/api/v1/map-pack/status");
    if (!res.ok) throw new Error("Failed to get map pack status");
    return res.json();
  },

  async getCameraStatus(): Promise<CameraStatus> {
    const res = await fetch("/api/v1/camera/status");
    if (!res.ok) throw new Error("Failed to get camera status");
    return res.json();
  },

  async getFlights(): Promise<FlightHistory[]> {
    const res = await fetch("/api/v1/flights");
    if (!res.ok) throw new Error("Failed to get flights");
    return res.json();
  },

  async landCommand(csrfToken: string): Promise<void> {
    const res = await fetch("/api/v1/commands/land", {
      method: "POST",
      headers: { "X-CSRF-Token": csrfToken },
    });
    if (!res.ok) {
        if (res.status === 423) throw new Error("Commands locked");
        throw new Error("Land command failed");
    }
  },
};
