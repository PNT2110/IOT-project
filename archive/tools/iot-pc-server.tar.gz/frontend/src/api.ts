export type Envelope<T> = {
  schema_version: string;
  request_id: string;
  data: T | null;
  error: { code: string; message_for_user: string } | null;
  observed_at: string;
};

export type Zone = {
  id: string;
  name: string;
  geometry: { type: "Polygon"; coordinates: number[][][] };
  visibility: "PUBLIC" | "INTERNAL";
  classification: "DEMO" | "INTERNAL_RESEARCH";
  version: number;
  retrieved_at: string;
  source_id?: string;
};

const API_BASE = import.meta.env.VITE_API_BASE ?? "";

type ApiOptions = RequestInit & { bearer?: string | null; ifMatch?: number; idempotencyKey?: string };

function csrfToken(): string | undefined {
  return document.cookie.split("; ").find((part) => part.startsWith("csrf="))?.slice(5);
}

async function request<T>(path: string, options: ApiOptions = {}): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set("Content-Type", "application/json");
  if (options.bearer) headers.set("Authorization", `Bearer ${options.bearer}`);
  if (options.ifMatch !== undefined) headers.set("If-Match", String(options.ifMatch));
  if (options.idempotencyKey) headers.set("Idempotency-Key", options.idempotencyKey);
  const method = (options.method ?? "GET").toUpperCase();
  if (method !== "GET" && method !== "HEAD" && !options.bearer) {
    const csrf = csrfToken();
    if (csrf) headers.set("X-CSRF-Token", csrf);
  }
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers, credentials: "include" });
  const payload = (await response.json()) as Envelope<T>;
  if (!response.ok || payload.error) throw new Error(payload.error?.message_for_user ?? "Yêu cầu không thành công");
  return payload.data as T;
}

export async function getPublicZones(): Promise<Zone[]> {
  const data = await request<{ items: Zone[] }>("/api/v1/public/zones");
  return data.items ?? [];
}

export async function getHealth(): Promise<{ status: string; local_only: boolean }> {
  return request<{ status: string; local_only: boolean }>("/api/v1/health");
}

export type Me = { id: string; display_name: string; email: string; status: string; role: string };
export type RegisterResult = { challenge_id: string; next_step: string; status: string };
export type EnrollmentResult = { enrollment_token: string; next_step: string };
export type MfaEnrollment = { secret: string; otpauth_uri: string; warning: string };
export type MfaConfirmation = { status: string; role: string; recovery_codes: string[]; warning: string };
export type LoginResult = { login_token: string; challenge_id: string; next_step: string };
export type AuthenticatedResult = { access_token: string; role: string; status: string; next_step: string };

export function register(body: { display_name: string; email: string; password: string; password_confirm: string; terms_version: string }) {
  return request<RegisterResult>("/api/v1/auth/register", { method: "POST", body: JSON.stringify(body) });
}

export function verifyEmail(token: string, code: string) {
  return request<EnrollmentResult>("/api/v1/auth/verify-email", { method: "POST", body: JSON.stringify({ challenge_id: token, code }) });
}

export function enrollMfa(token: string) {
  return request<MfaEnrollment>("/api/v1/auth/mfa/enroll", { method: "POST", bearer: token });
}

export function confirmMfa(token: string, code: string) {
  return request<MfaConfirmation>("/api/v1/auth/mfa/confirm", { method: "POST", bearer: token, body: JSON.stringify({ code }) });
}

export function login(body: { email: string; password: string; terms_version: string }) {
  return request<LoginResult>("/api/v1/auth/login", { method: "POST", body: JSON.stringify(body) });
}

export function verifyLoginOtp(token: string, challengeId: string, code: string) {
  return request<{ login_token: string; next_step: string }>("/api/v1/auth/verify-login-otp", { method: "POST", bearer: token, body: JSON.stringify({ challenge_id: challengeId, code }) });
}

export function verifyTotp(token: string, code: string) {
  return request<AuthenticatedResult>("/api/v1/auth/verify-totp", { method: "POST", bearer: token, body: JSON.stringify({ code }) });
}

export function getMe() {
  return request<Me>("/api/v1/auth/me");
}

export function logout() {
  return request<{ logged_out: boolean }>("/api/v1/auth/logout", { method: "POST" });
}

export type Account = { id: string; display_name: string; email: string; status: string; role: string; version: number; email_verified: boolean; created_at: string; updated_at: string };
export type RoleElevation = { id: string; requester_user_id: string; requested_role: "OPERATOR" | "ADMIN"; status: string; reason: string; reviewer_user_id: string | null; reviewer_reason: string | null; version: number };
export type FlightRequest = { id: string; submitter_user_id: string; summary: string; scheduled_start_at: string; scheduled_end_at: string; geometry: Zone["geometry"]; status: string; version: number; simulated: boolean; label: string; source: string };
export type ReviewActionCapability = { allowed: boolean; scope: string };
export type ReviewCapabilities = {
  policy: "OWNER_OR_GRANTED_ADMIN_SCOPED";
  can_approve_accounts: boolean;
  can_approve_admin_role: boolean;
  account_approve: ReviewActionCapability;
  admin_role_approve: ReviewActionCapability;
  role: string;
  status: string;
};
export type AccountReviewList = { items: Account[]; page: number; page_size: number; role_policy: ReviewCapabilities["policy"]; effective_capabilities: ReviewCapabilities };

export function listAccounts() {
  return request<AccountReviewList>("/api/v1/account-review/users");
}

export function getReviewCapabilities() {
  return request<ReviewCapabilities>("/api/v1/account-review/capabilities");
}

export function reviewAccount(id: string, version: number, status: "ACTIVE" | "REJECTED" | "SUSPENDED", reason: string) {
  return request<{ account: Account }>(`/api/v1/account-review/users/${id}/status`, { method: "POST", ifMatch: version, body: JSON.stringify({ status, reason }) });
}

export function createRoleElevation(requested_role: "OPERATOR" | "ADMIN", reason: string) {
  return request<RoleElevation>("/api/v1/role-elevations", { method: "POST", idempotencyKey: `ui-role-${crypto.randomUUID()}`, body: JSON.stringify({ requested_role, reason }) });
}

export function listRoleElevations() {
  return request<{ items: RoleElevation[] }>("/api/v1/role-elevations");
}

export function listRoleElevationReview() {
  return request<{ items: RoleElevation[]; policy: ReviewCapabilities["policy"]; effective_capabilities: ReviewCapabilities }>("/api/v1/role-elevations/review");
}

export function decideRoleElevation(id: string, version: number, decision: "APPROVED" | "REJECTED", reason: string) {
  return request<RoleElevation>(`/api/v1/role-elevations/${id}/decision`, { method: "POST", ifMatch: version, idempotencyKey: `ui-role-decision-${crypto.randomUUID()}`, body: JSON.stringify({ decision, reason }) });
}

export function createFlight(body: { summary: string; scheduled_start_at: string; scheduled_end_at: string; geometry: Zone["geometry"] }) {
  return request<FlightRequest>("/api/v1/simulated/flight-requests", { method: "POST", idempotencyKey: `ui-flight-${crypto.randomUUID()}`, body: JSON.stringify(body) });
}

export function listFlights() {
  return request<{ items: FlightRequest[] }>("/api/v1/simulated/flight-requests");
}

export function submitFlight(id: string, version: number, reason: string) {
  return request<FlightRequest>(`/api/v1/simulated/flight-requests/${id}/submit`, { method: "POST", ifMatch: version, idempotencyKey: `ui-flight-submit-${crypto.randomUUID()}`, body: JSON.stringify({ reason }) });
}

export function reviewFlight(id: string, version: number, reason: string) {
  return request<FlightRequest>(`/api/v1/simulated/flight-requests/${id}/review`, { method: "POST", ifMatch: version, idempotencyKey: `ui-flight-review-${crypto.randomUUID()}`, body: JSON.stringify({ reason }) });
}

export function decideFlight(id: string, version: number, decision: "NEEDS_INFORMATION" | "REJECTED" | "APPROVED_SIMULATED", reason: string) {
  return request<FlightRequest>(`/api/v1/simulated/flight-requests/${id}/decision`, { method: "POST", ifMatch: version, idempotencyKey: `ui-flight-decision-${crypto.randomUUID()}`, body: JSON.stringify({ decision, reason }) });
}
