import { useCallback, useEffect, useState } from "react";
import { getHealth, getPublicZones, type Zone } from "./api";

type Health = { status: string; local_only: boolean };

export function App() {
  const [health, setHealth] = useState<Health | null>(null);
  const [zones, setZones] = useState<Zone[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const loadOverview = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [healthData, zoneData] = await Promise.all([getHealth(), getPublicZones()]);
      setHealth(healthData);
      setZones(zoneData);
      setLastChecked(new Date());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Không thể kết nối PC server");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadOverview();
  }, [loadOverview]);

  const online = health?.status === "ok";

  return (
    <main className="site-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark">I</div>
          <div>
            <div className="brand-name">IOT DRONE STATION</div>
            <div className="brand-caption">PC control plane · simulation environment</div>
          </div>
        </div>
        <div className={`connection-pill ${online ? "is-online" : "is-offline"}`}>
          <span className="connection-dot" />
          {loading ? "ĐANG KIỂM TRA" : online ? "SERVER ONLINE" : "SERVER OFFLINE"}
        </div>
      </header>

      <section className="hero-section">
        <div className="hero-copy">
          <p className="eyebrow">PC SERVER / SCOPE 01–02</p>
          <h1>Trung tâm điều phối<br /><span>an toàn cho dữ liệu drone.</span></h1>
          <p className="hero-description">
            Dashboard PC kết nối trực tiếp với API canonical, hiển thị dữ liệu vùng bay
            tổng hợp và trạng thái môi trường mô phỏng.
          </p>
          <div className="hero-actions">
            <button className="primary-button" type="button" onClick={() => void loadOverview()} disabled={loading}>
              {loading ? "Đang tải…" : "Kiểm tra kết nối"}
            </button>
            <a className="ghost-button" href="/docs" target="_blank" rel="noreferrer">Mở API docs ↗</a>
          </div>
          {error && <div className="error-banner">{error}</div>}
        </div>

        <div className="hero-visual" aria-hidden="true">
          <div className="radar-ring ring-one" />
          <div className="radar-ring ring-two" />
          <div className="radar-ring ring-three" />
          <div className="radar-sweep" />
          <div className="radar-center">IOT</div>
          <span className="radar-point point-one" />
          <span className="radar-point point-two" />
          <span className="radar-point point-three" />
        </div>
      </section>

      <section className="metrics-grid" aria-label="Trạng thái hệ thống">
        <article className="metric-card">
          <span className="metric-label">API STATUS</span>
          <strong className={online ? "metric-good" : "metric-bad"}>{health?.status?.toUpperCase() ?? "—"}</strong>
          <small>FastAPI · port 8765</small>
        </article>
        <article className="metric-card">
          <span className="metric-label">RUNTIME MODE</span>
          <strong>LOCAL-ONLY</strong>
          <small>Không điều khiển phần cứng</small>
        </article>
        <article className="metric-card">
          <span className="metric-label">PUBLIC ZONES</span>
          <strong>{zones.length.toString().padStart(2, "0")}</strong>
          <small>Dữ liệu bản đồ tổng hợp</small>
        </article>
        <article className="metric-card">
          <span className="metric-label">LAST CHECK</span>
          <strong>{lastChecked ? lastChecked.toLocaleTimeString("vi-VN") : "—"}</strong>
          <small>UTC+7 · browser time</small>
        </article>
      </section>

      <section className="content-section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">PUBLIC DATA / READ ONLY</p>
            <h2>Khu vực bay tổng hợp</h2>
          </div>
          <span className="section-note">{zones.length} khu vực</span>
        </div>
        {zones.length === 0 ? (
          <div className="empty-state">Chưa có dữ liệu khu vực công khai.</div>
        ) : (
          <div className="zone-grid">
            {zones.map((zone) => (
              <article className="zone-card" key={zone.id}>
                <div className="zone-icon">⌖</div>
                <div className="zone-body">
                  <h3>{zone.name}</h3>
                  <p>{zone.classification.replaceAll("_", " ")} · {zone.visibility}</p>
                </div>
                <span className="zone-status">READ ONLY</span>
              </article>
            ))}
          </div>
        )}
      </section>

      <footer className="site-footer">
        <span>SIMULATED — NOT A FLIGHT PERMIT</span>
        <span>© IOT Research Prototype</span>
      </footer>
    </main>
  );
}
