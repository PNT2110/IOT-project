import { useState, useEffect, useCallback, useMemo } from 'react';
import { apiClient } from '../api/client';

export interface AuthUser {
  username: string;
  role: string;
}

export function useAuth() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [csrfToken, setCsrfToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchMe = useCallback(async () => {
    try {
      const userData = await apiClient.getMe();
      setUser({ username: userData.username, role: userData.role });
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMe();
  }, [fetchMe]);

  /**
   * Login by calling the backend API. Used when auth form is handled externally.
   */
  const login = useCallback((username: string, password: string, totp?: string) => {
    return apiClient.login(username, password, totp).then((data) => {
      setUser({ username: data.username, role: data.role });
      setCsrfToken(data.csrf_token);
      return data;
    });
  }, []);

  /**
   * Set auth state directly from a LoginResponse (when LoginPanel already called the API).
   */
  const handleLogin = useCallback((username: string, csrfTokenVal: string) => {
    // Re-fetch user from /api/v1/auth/me to get accurate role
    setCsrfToken(csrfTokenVal);
    fetchMe();
  }, [fetchMe]);

  const handleLogout = useCallback(async () => {
    if (csrfToken) {
      try {
        await apiClient.logout(csrfToken);
      } catch (err) {
        console.error("Logout error", err);
      }
    }
    setUser(null);
    setCsrfToken(null);
  }, [csrfToken]);

  const isAdmin = useMemo(() => user?.role === 'admin', [user]);

  return {
    user,
    csrfToken,
    loading,
    login,
    handleLogin,
    logout: handleLogout,
    isAdmin,
  };
}
