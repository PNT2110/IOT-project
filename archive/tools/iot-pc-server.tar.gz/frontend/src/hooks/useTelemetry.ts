import { useState, useEffect, useRef } from 'react';
import { TelemetryFrame } from '../api/client';

export function useTelemetry(isAdmin: boolean) {
  const [telemetry, setTelemetry] = useState<TelemetryFrame | null>(null);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeout = useRef<number | null>(null);

  useEffect(() => {
    if (!isAdmin) {
      setConnected(false);
      if (wsRef.current) {
        wsRef.current.close();
      }
      return;
    }

    let isSubscribed = true;
    let backoff = 1000;

    const connect = () => {
      if (!isSubscribed) return;
      
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/telemetry`;
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        if (!isSubscribed) return;
        setConnected(true);
        backoff = 1000; // Reset backoff on success
      };

      ws.onmessage = (event) => {
        if (!isSubscribed) return;
        try {
          const frame: TelemetryFrame = JSON.parse(event.data);
          setTelemetry(frame);
        } catch (e) {
          console.error("Failed to parse telemetry:", e);
        }
      };

      ws.onclose = () => {
        if (!isSubscribed) return;
        setConnected(false);
        wsRef.current = null;
        reconnectTimeout.current = window.setTimeout(connect, backoff);
        backoff = Math.min(backoff * 1.5, 30000);
      };

      ws.onerror = (err) => {
        console.error("Telemetry WebSocket error:", err);
      };
    };

    connect();

    return () => {
      isSubscribed = false;
      if (reconnectTimeout.current !== null) {
        clearTimeout(reconnectTimeout.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [isAdmin]);

  return { telemetry, connected };
}
