import React from 'react';

export interface Attitude {
  roll: number;
  pitch: number;
  yaw: number;
}

interface Attitude3DProps {
  attitude: Attitude;
  flightMode: string;
  armed: boolean;
}

export const Attitude3D: React.FC<Attitude3DProps> = ({ attitude, flightMode, armed }) => {
  // SVG-based attitude indicator
  const { roll, pitch, yaw } = attitude;
  
  // Constrain pitch for display
  const pitchDisplay = Math.max(-45, Math.min(45, pitch));
  const pitchOffset = (pitchDisplay / 45) * 50; // Translate pixels

  return (
    <div style={{
      backgroundColor: '#1e1e1e',
      color: '#fff',
      padding: '16px',
      borderRadius: '8px',
      fontFamily: 'sans-serif',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '12px'
    }}>
      <div style={{ display: 'flex', width: '100%', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <span style={{ color: '#aaa', fontSize: '0.8rem', display: 'block' }}>Chế độ bay</span>
          <span style={{ fontSize: '1.1rem', fontWeight: 'bold' }}>{flightMode}</span>
        </div>
        <div style={{
          padding: '6px 12px',
          borderRadius: '4px',
          backgroundColor: armed ? '#dc3545' : '#6c757d',
          fontWeight: 'bold',
          animation: armed ? 'pulse 2s infinite' : 'none'
        }}>
          {armed ? 'ĐANG BAY (ARMED)' : 'CHƯA SẴN SÀNG'}
        </div>
      </div>

      <div style={{
        position: 'relative',
        width: '200px',
        height: '200px',
        borderRadius: '50%',
        overflow: 'hidden',
        border: '4px solid #333',
        backgroundColor: '#87CEEB' // Sky blue
      }}>
        {/* Horizon and Ground */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '-50%',
          width: '200%',
          height: '200%',
          backgroundColor: '#8B4513', // Ground brown
          transformOrigin: 'top center',
          transform: `translateY(${pitchOffset}px) rotate(${-roll}deg)`
        }}>
          <div style={{ width: '100%', height: '2px', backgroundColor: '#fff' }} />
        </div>
        
        {/* Fixed Drone Reticle */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '60px',
          height: '2px',
          backgroundColor: 'red'
        }} />
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '10px',
          height: '10px',
          borderRadius: '50%',
          border: '2px solid red'
        }} />
      </div>

      <div style={{ display: 'flex', gap: '16px', width: '100%', justifyContent: 'space-around', fontSize: '0.9rem' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#aaa' }}>Cuộn (Roll)</div>
          <div>{roll.toFixed(1)}°</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#aaa' }}>Ngẩng (Pitch)</div>
          <div>{pitch.toFixed(1)}°</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#aaa' }}>Hướng (Yaw)</div>
          <div>{yaw.toFixed(1)}°</div>
        </div>
      </div>
      
      <style>{`
        @keyframes pulse {
          0% { opacity: 1; }
          50% { opacity: 0.7; }
          100% { opacity: 1; }
        }
      `}</style>
    </div>
  );
};
