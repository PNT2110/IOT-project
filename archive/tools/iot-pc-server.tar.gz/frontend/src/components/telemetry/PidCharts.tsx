import React, { useState, useEffect, useRef } from 'react';

export interface PidAxis {
  kp: number;
  ki: number;
  kd: number;
  setpoint: number;
  measured: number;
  output: number;
}

export interface PidData {
  roll: PidAxis;
  pitch: PidAxis;
  yaw: PidAxis;
}

interface PidChartsProps {
  pid: PidData;
}

const Chart: React.FC<{ title: string, data: { s: number, m: number, o: number }[] }> = ({ title, data }) => {
  if (data.length === 0) return null;
  const width = 300;
  const height = 80;
  
  // Find min/max for scaling
  let min = 0;
  let max = 0;
  data.forEach(d => {
    if (d.s < min) min = d.s;
    if (d.m < min) min = d.m;
    if (d.s > max) max = d.s;
    if (d.m > max) max = d.m;
  });
  
  // Add some padding
  const range = (max - min) || 1;
  const scaleY = (val: number) => height - ((val - min) / range * height * 0.8 + height * 0.1);
  const scaleX = (idx: number) => (idx / 100) * width;

  const pathSetpoint = data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${scaleX(i)} ${scaleY(d.s)}`).join(' ');
  const pathMeasured = data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${scaleX(i)} ${scaleY(d.m)}`).join(' ');

  return (
    <div style={{ marginBottom: '12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '4px' }}>
        <span>{title}</span>
        <div style={{ display: 'flex', gap: '8px' }}>
          <span style={{ color: '#4da6ff' }}>-- Đặt</span>
          <span style={{ color: '#28a745' }}>- Đo</span>
          <span style={{ color: '#dc3545' }}>Out: {data[data.length-1]?.o.toFixed(1)}</span>
        </div>
      </div>
      <div style={{ background: '#111', borderRadius: '4px', overflow: 'hidden' }}>
        <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
          {/* Grid lines */}
          <line x1="0" y1={height/2} x2={width} y2={height/2} stroke="#333" strokeDasharray="4" />
          
          <path d={pathSetpoint} fill="none" stroke="#4da6ff" strokeWidth="1.5" strokeDasharray="4" />
          <path d={pathMeasured} fill="none" stroke="#28a745" strokeWidth="1.5" />
        </svg>
      </div>
    </div>
  );
};

export const PidCharts: React.FC<PidChartsProps> = ({ pid }) => {
  const [history, setHistory] = useState<{
    roll: {s: number, m: number, o: number}[],
    pitch: {s: number, m: number, o: number}[],
    yaw: {s: number, m: number, o: number}[]
  }>({ roll: [], pitch: [], yaw: [] });

  useEffect(() => {
    setHistory(prev => {
      const newRoll = [...prev.roll, { s: pid.roll.setpoint, m: pid.roll.measured, o: pid.roll.output }].slice(-100);
      const newPitch = [...prev.pitch, { s: pid.pitch.setpoint, m: pid.pitch.measured, o: pid.pitch.output }].slice(-100);
      const newYaw = [...prev.yaw, { s: pid.yaw.setpoint, m: pid.yaw.measured, o: pid.yaw.output }].slice(-100);
      return { roll: newRoll, pitch: newPitch, yaw: newYaw };
    });
  }, [pid]);

  return (
    <div style={{
      backgroundColor: '#1e1e1e',
      color: '#fff',
      padding: '16px',
      borderRadius: '8px',
      fontFamily: 'sans-serif'
    }}>
      <h3 style={{ margin: '0 0 12px 0', fontSize: '1.2rem', color: '#4da6ff' }}>PID Charts</h3>
      <Chart title="PID Roll" data={history.roll} />
      <Chart title="PID Pitch" data={history.pitch} />
      <Chart title="PID Yaw" data={history.yaw} />
    </div>
  );
};
