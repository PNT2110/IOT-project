import React from 'react';

export interface GpsFix {
  latitude: number;
  longitude: number;
  altitude_m: number;
  speed_mps: number;
  course_deg: number;
  satellites: number;
  hdop: number;
  fix_quality: number;
  valid: boolean;
  stale: boolean;
  raw?: string;
}

interface GpsPanelProps {
  gps: GpsFix;
}

export const GpsPanel: React.FC<GpsPanelProps> = ({ gps }) => {
  const speedKmh = (gps.speed_mps * 3.6).toFixed(1);

  const getFixQualityText = (quality: number) => {
    switch (quality) {
      case 0: return 'Không có Fix';
      case 1: return 'GPS (SPS)';
      case 2: return 'DGPS';
      case 3: return 'PPS';
      case 4: return 'RTK Kinematic';
      case 5: return 'RTK Float';
      case 6: return 'Ước lượng';
      default: return 'Không xác định';
    }
  };

  return (
    <div style={{
      backgroundColor: '#1e1e1e',
      color: '#fff',
      padding: '16px',
      borderRadius: '8px',
      fontFamily: 'sans-serif',
      display: 'flex',
      flexDirection: 'column',
      gap: '8px'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ margin: 0, fontSize: '1.2rem', color: '#4da6ff' }}>GPS</h3>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          {gps.stale && <span style={{ color: '#ffd700', fontSize: '0.8rem', fontWeight: 'bold' }}>⚠️ DỮ LIỆU CŨ</span>}
          <span style={{
            padding: '4px 8px',
            borderRadius: '4px',
            fontSize: '0.8rem',
            backgroundColor: gps.valid ? '#28a745' : '#dc3545',
            color: '#fff'
          }}>
            {gps.valid ? 'HỢP LỆ' : 'KHÔNG HỢP LỆ'}
          </span>
        </div>
      </div>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '0.9rem' }}>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>Vĩ độ</div>
          <div>{gps.latitude.toFixed(6)}°</div>
        </div>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>Kinh độ</div>
          <div>{gps.longitude.toFixed(6)}°</div>
        </div>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>Cao độ</div>
          <div>{gps.altitude_m.toFixed(1)} m</div>
        </div>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>Tốc độ</div>
          <div>{speedKmh} km/h</div>
        </div>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>Hướng</div>
          <div>{gps.course_deg.toFixed(1)}°</div>
        </div>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>Vệ tinh</div>
          <div>🛰️ {gps.satellites}</div>
        </div>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>HDOP</div>
          <div>{gps.hdop.toFixed(2)}</div>
        </div>
        <div style={{ background: '#2d2d2d', padding: '8px', borderRadius: '4px' }}>
          <div style={{ color: '#aaa', fontSize: '0.8rem' }}>Chất lượng fix</div>
          <div>{getFixQualityText(gps.fix_quality)}</div>
        </div>
      </div>
    </div>
  );
};
