import React, { useState, useEffect } from 'react';

interface CameraStatus {
  available: boolean;
  mode?: string;
  message?: string;
}

export const CameraView: React.FC = () => {
  const [status, setStatus] = useState<CameraStatus>({ available: false });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch('/api/v1/camera/status');
        if (res.ok) {
          const data = await res.json();
          setStatus(data);
        }
      } catch (err) {
        setStatus({ available: false, message: 'Lỗi kết nối' });
      } finally {
        setLoading(false);
      }
    };

    fetchStatus();
    // In a real app, might want to poll this if it changes dynamically
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{
      backgroundColor: '#111',
      border: '1px solid #333',
      borderRadius: '8px',
      overflow: 'hidden',
      fontFamily: 'sans-serif',
      display: 'flex',
      flexDirection: 'column',
      aspectRatio: '16/9',
      position: 'relative'
    }}>
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        padding: '8px 12px',
        background: 'linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)',
        color: '#fff',
        display: 'flex',
        justifyContent: 'space-between',
        zIndex: 10
      }}>
        <div style={{ fontWeight: 'bold' }}>Camera Feed</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: status.available ? '#28a745' : '#dc3545'
          }} />
          <span style={{ fontSize: '0.8rem' }}>
            {status.available ? (status.mode || 'Sẵn sàng') : 'Mất kết nối'}
          </span>
        </div>
      </div>

      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#666',
        backgroundColor: '#0a0a0a'
      }}>
        {loading ? (
          <div>Đang kiểm tra...</div>
        ) : status.available ? (
          <div style={{ color: '#aaa' }}>
            {/* Future WebRTC player goes here */}
            <div style={{ fontSize: '3rem', textAlign: 'center', marginBottom: '16px' }}>📹</div>
            <div>[Luồng Video WebRTC sẽ hiển thị ở đây]</div>
          </div>
        ) : (
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '3rem', marginBottom: '8px', opacity: 0.5 }}>📷</div>
            <div>Chưa kết nối camera</div>
            {status.message && <div style={{ fontSize: '0.8rem', marginTop: '4px', color: '#888' }}>{status.message}</div>}
          </div>
        )}
      </div>
    </div>
  );
};
