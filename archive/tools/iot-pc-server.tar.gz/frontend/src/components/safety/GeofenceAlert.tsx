import React from 'react';

export interface GeofenceState {
  status: "unknown" | "safe" | "warning" | "breach";
  zone_id?: string;
  zone_name?: string;
  distance_m?: number;
  data_ready: boolean;
  checked_at?: number;
}

interface GeofenceAlertProps {
  geofence: GeofenceState;
}

export const GeofenceAlert: React.FC<GeofenceAlertProps> = ({ geofence }) => {
  const getAlertStyles = () => {
    switch (geofence.status) {
      case 'safe':
        return { border: '2px solid #28a745', color: '#28a745', bg: 'rgba(40, 167, 69, 0.1)', anim: 'none' };
      case 'warning':
        return { border: '2px solid #ffc107', color: '#ffc107', bg: 'rgba(255, 193, 7, 0.1)', anim: 'pulseWarning 1.5s infinite' };
      case 'breach':
        return { border: '2px solid #dc3545', color: '#dc3545', bg: 'rgba(220, 53, 69, 0.2)', anim: 'pulseBreach 1s infinite' };
      default:
        return { border: '2px solid #6c757d', color: '#6c757d', bg: 'rgba(108, 117, 125, 0.1)', anim: 'none' };
    }
  };

  const styles = getAlertStyles();

  return (
    <>
      <style>{`
        @keyframes pulseWarning {
          0% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0.7); }
          70% { box-shadow: 0 0 0 10px rgba(255, 193, 7, 0); }
          100% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0); }
        }
        @keyframes pulseBreach {
          0% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.7); }
          70% { box-shadow: 0 0 0 15px rgba(220, 53, 69, 0); }
          100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0); }
        }
      `}</style>
      <div style={{
        padding: '16px',
        borderRadius: '8px',
        border: styles.border,
        backgroundColor: styles.bg,
        color: styles.color,
        fontFamily: 'sans-serif',
        animation: styles.anim,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        textAlign: 'center',
        gap: '8px'
      }}>
        <h3 style={{ margin: 0, fontSize: '1.2rem', textTransform: 'uppercase' }}>
          {geofence.status === 'safe' && 'An toàn'}
          {geofence.status === 'warning' && 'Cảnh báo: Gần vùng cấm'}
          {geofence.status === 'breach' && 'CẢNH BÁO: TRONG VÙNG CẤM!'}
          {geofence.status === 'unknown' && 'Chưa xác định'}
        </h3>
        
        {(geofence.status === 'warning' || geofence.status === 'breach') && geofence.zone_name && (
          <div style={{ fontWeight: 'bold' }}>Khu vực: {geofence.zone_name}</div>
        )}
        
        {geofence.status === 'warning' && geofence.distance_m !== undefined && (
          <div>Khoảng cách: {geofence.distance_m.toFixed(1)} m</div>
        )}
      </div>
    </>
  );
};
