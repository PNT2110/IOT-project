import React, { useState } from 'react';

interface LandButtonProps {
  csrfToken: string;
  armed: boolean;
  espConnected: boolean;
}

export const LandButton: React.FC<LandButtonProps> = ({ csrfToken, armed, espConnected }) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLand = async () => {
    setLoading(true);
    setStatusMsg('Đang gửi lệnh...');
    try {
      const res = await fetch('/api/v1/commands/land', {
        method: 'POST',
        headers: {
          'X-CSRF-Token': csrfToken
        }
      });

      if (res.status === 423) {
        setStatusMsg('Lệnh bay thật đang bị khóa an toàn');
      } else if (res.status === 503) {
        setStatusMsg('ESP chưa kết nối');
      } else if (res.status === 504) {
        setStatusMsg('ESP không phản hồi');
      } else if (res.ok) {
        setStatusMsg('Đã gửi lệnh HẠ CÁNH thành công!');
      } else {
        setStatusMsg(`Lỗi hệ thống: ${res.status}`);
      }
    } catch (err) {
      setStatusMsg('Lỗi kết nối mạng');
    } finally {
      setLoading(false);
      setShowConfirm(false);
      setTimeout(() => setStatusMsg(''), 5000);
    }
  };

  return (
    <div style={{ fontFamily: 'sans-serif', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {!showConfirm ? (
        <button 
          onClick={() => setShowConfirm(true)}
          disabled={!espConnected || !armed}
          style={{
            backgroundColor: (!espConnected || !armed) ? '#555' : '#dc3545',
            color: '#fff',
            padding: '16px 24px',
            fontSize: '1.2rem',
            fontWeight: 'bold',
            border: 'none',
            borderRadius: '8px',
            cursor: (!espConnected || !armed) ? 'not-allowed' : 'pointer',
            width: '100%',
            transition: 'background-color 0.2s'
          }}
        >
          HẠ CÁNH KHẨN CẤP
        </button>
      ) : (
        <div style={{
          backgroundColor: '#333',
          padding: '16px',
          borderRadius: '8px',
          border: '1px solid #dc3545'
        }}>
          <p style={{ margin: '0 0 16px 0', color: '#fff', textAlign: 'center', fontWeight: 'bold' }}>
            Xác nhận gửi lệnh hạ cánh?
          </p>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button 
              onClick={handleLand}
              disabled={loading}
              style={{
                flex: 1,
                backgroundColor: '#dc3545',
                color: '#fff',
                padding: '10px',
                border: 'none',
                borderRadius: '4px',
                fontWeight: 'bold',
                cursor: loading ? 'wait' : 'pointer'
              }}
            >
              {loading ? 'Đang gửi...' : 'Xác nhận'}
            </button>
            <button 
              onClick={() => setShowConfirm(false)}
              disabled={loading}
              style={{
                flex: 1,
                backgroundColor: '#6c757d',
                color: '#fff',
                padding: '10px',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'wait' : 'pointer'
              }}
            >
              Hủy
            </button>
          </div>
        </div>
      )}
      
      {statusMsg && (
        <div style={{
          padding: '8px',
          borderRadius: '4px',
          backgroundColor: 'rgba(255,255,255,0.1)',
          color: statusMsg.includes('thành công') ? '#28a745' : '#ffc107',
          textAlign: 'center',
          fontSize: '0.9rem'
        }}>
          {statusMsg}
        </div>
      )}
    </div>
  );
};
