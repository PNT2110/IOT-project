import React, { useState, useEffect, useRef } from 'react';

export const RawMonitor: React.FC = () => {
  const [lines, setLines] = useState<string[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchRaw = async () => {
      try {
        const res = await fetch('/api/v1/serial/raw');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) {
            setLines(prev => {
              const newLines = [...prev, ...data];
              return newLines.slice(-200); // keep last 200
            });
          } else if (data.lines) {
            setLines(prev => {
              const newLines = [...prev, ...data.lines];
              return newLines.slice(-200);
            });
          }
        }
      } catch (err) {
        console.error('Failed to fetch raw serial:', err);
      }
    };

    const intervalId = setInterval(fetchRaw, 1000);
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [lines]);

  return (
    <div style={{
      backgroundColor: '#000',
      color: '#0f0',
      padding: '12px',
      borderRadius: '8px',
      fontFamily: 'monospace',
      display: 'flex',
      flexDirection: 'column',
      height: '300px'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #333', paddingBottom: '8px', marginBottom: '8px' }}>
        <h3 style={{ margin: 0, fontSize: '1rem', color: '#fff' }}>Serial Monitor</h3>
        <span style={{ fontSize: '0.8rem', color: '#888' }}>{lines.length} lines</span>
      </div>
      <div 
        ref={containerRef}
        style={{ 
          flex: 1, 
          overflowY: 'auto', 
          fontSize: '0.85rem',
          lineHeight: '1.4',
          whiteSpace: 'pre-wrap'
        }}
      >
        {lines.length === 0 ? (
          <span style={{ color: '#555' }}>Đang chờ dữ liệu...</span>
        ) : (
          lines.map((line, i) => (
            <div key={i}>{line}</div>
          ))
        )}
      </div>
    </div>
  );
};
