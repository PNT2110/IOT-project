import React, { useState } from 'react';

export interface LoginResponse {
  username: string;
  role: string;
  csrf_token: string;
}

interface LoginPanelProps {
  onLogin: (response: LoginResponse) => void;
}

export const LoginPanel: React.FC<LoginPanelProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [totp, setTotp] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const response = await fetch('/api/v1/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password, totp: totp || undefined }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => null);
        throw new Error(errData?.detail || 'Đăng nhập thất bại');
      }

      const data: LoginResponse = await response.json();
      onLogin(data);
    } catch (err: any) {
      setError(err.message || 'Lỗi kết nối');
    } finally {
      setLoading(false);
    }
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      backgroundColor: '#0a0a0f',
      color: '#ffffff',
      fontFamily: 'sans-serif',
    },
    panel: {
      backgroundColor: '#12121a',
      padding: '2rem',
      borderRadius: '8px',
      border: '1px solid #2a2a3a',
      width: '100%',
      maxWidth: '400px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.3)',
    },
    title: {
      margin: '0 0 1.5rem 0',
      textAlign: 'center' as const,
      color: '#4dabf7',
    },
    inputGroup: {
      marginBottom: '1rem',
      display: 'flex',
      flexDirection: 'column' as const,
    },
    label: {
      marginBottom: '0.5rem',
      fontSize: '0.9rem',
      color: '#a0a0b0',
    },
    input: {
      padding: '0.75rem',
      borderRadius: '4px',
      border: '1px solid #2a2a3a',
      backgroundColor: '#1a1a24',
      color: '#ffffff',
      outline: 'none',
      fontSize: '1rem',
    },
    button: {
      width: '100%',
      padding: '0.75rem',
      marginTop: '1rem',
      backgroundColor: '#4dabf7',
      color: '#ffffff',
      border: 'none',
      borderRadius: '4px',
      fontSize: '1rem',
      fontWeight: 'bold',
      cursor: loading ? 'not-allowed' : 'pointer',
      opacity: loading ? 0.7 : 1,
    },
    error: {
      color: '#ff6b6b',
      backgroundColor: '#2b1515',
      padding: '0.75rem',
      borderRadius: '4px',
      marginBottom: '1rem',
      fontSize: '0.9rem',
      border: '1px solid #4a1c1c',
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.panel}>
        <h2 style={styles.title}>IOT Drone Station</h2>
        {error && <div style={styles.error}>{error}</div>}
        <form onSubmit={handleSubmit}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Tên đăng nhập</label>
            <input
              style={styles.input}
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              autoComplete="username"
            />
          </div>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Mật khẩu</label>
            <input
              style={styles.input}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
          </div>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Mã TOTP (admin)</label>
            <input
              style={styles.input}
              type="text"
              value={totp}
              onChange={(e) => setTotp(e.target.value)}
              placeholder="Tùy chọn cho admin"
              autoComplete="one-time-code"
            />
          </div>
          <button style={styles.button} type="submit" disabled={loading}>
            {loading ? 'Đang xử lý...' : 'Đăng nhập'}
          </button>
        </form>
      </div>
    </div>
  );
};
