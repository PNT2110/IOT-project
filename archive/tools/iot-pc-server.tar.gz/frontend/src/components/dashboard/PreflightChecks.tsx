import React, { useEffect, useState } from 'react';

export const PreflightChecks: React.FC = () => {
  const [preflight, setPreflight] = useState<any>(null);

  useEffect(() => {
    const fetchPreflight = async () => {
      try {
        const res = await fetch('/api/v1/preflight');
        if (res.ok) {
          const data = await res.json();
          setPreflight(data);
        }
      } catch (err) {
        console.error('Lỗi khi tải preflight', err);
      }
    };
    
    fetchPreflight();
    const interval = setInterval(fetchPreflight, 5000);
    return () => clearInterval(interval);
  }, []);

  if (!preflight) return <div style={{color: '#a0a0b0'}}>Đang kiểm tra trước bay...</div>;

  const checks = [
    { label: 'GPS Kết nối', passed: preflight.gps?.connected },
    { label: 'Tín hiệu GPS Tốt', passed: preflight.gps?.valid_fix },
    { label: 'GPS Mới', passed: !preflight.gps?.stale },
    { label: 'ESP Kết nối', passed: preflight.esp?.connected },
    { label: 'Dữ liệu Geofence', passed: preflight.geofence?.data_ready },
    { label: 'Geofence Đồng bộ', passed: preflight.geofence?.sync_fresh },
    { label: 'Bản đồ Offline', passed: preflight.map?.file_present },
    { label: 'Mở khóa Lệnh', passed: preflight.firmware?.commands_enabled }
  ];

  const overallReady = checks.every(c => c.passed);

  const styles = {
    container: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
      backgroundColor: '#1a1a24',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
      border: `1px solid ${overallReady ? '#40c057' : '#ff6b6b'}`
    },
    title: {
      margin: 0,
      fontSize: '0.9rem',
      color: '#a0a0b0',
      fontWeight: 'bold',
      marginRight: '0.5rem'
    },
    list: {
      display: 'flex',
      gap: '1rem',
      flexWrap: 'wrap' as const
    },
    item: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      fontSize: '0.85rem'
    },
    icon: (passed: boolean) => ({
      color: passed ? '#40c057' : '#ff6b6b',
      fontWeight: 'bold'
    }),
    statusBox: {
      padding: '0.4rem 0.8rem',
      borderRadius: '4px',
      fontWeight: 'bold',
      backgroundColor: overallReady ? 'rgba(64, 192, 87, 0.2)' : 'rgba(255, 107, 107, 0.2)',
      color: overallReady ? '#40c057' : '#ff6b6b'
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.title}>PREFLIGHT CHEKS</div>
      <div style={styles.list}>
        {checks.map((chk, i) => (
          <div key={i} style={styles.item}>
            <span style={styles.icon(chk.passed)}>{chk.passed ? '✓' : '✗'}</span>
            <span style={{ color: chk.passed ? '#e0e0e0' : '#a0a0b0' }}>{chk.label}</span>
          </div>
        ))}
      </div>
      <div style={styles.statusBox}>
        {overallReady ? 'READY' : 'NOT READY'}
      </div>
    </div>
  );
};
