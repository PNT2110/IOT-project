import React, { useEffect, useState } from 'react';

export const SystemStatus: React.FC = () => {
  const [status, setStatus] = useState<any>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch('/api/v1/status');
        if (res.ok) {
          const data = await res.json();
          setStatus(data);
        }
      } catch (err) {
        console.error('Lỗi khi tải trạng thái hệ thống', err);
      }
    };
    
    fetchStatus();
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  if (!status) return <div style={{color: '#a0a0b0'}}>Đang tải...</div>;

  const styles = {
    row: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '0.4rem 0',
      borderBottom: '1px solid #1a1a24',
      fontSize: '0.95rem'
    },
    label: {
      color: '#a0a0b0'
    },
    valueWrapper: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    },
    dot: (active: boolean) => ({
      width: '10px',
      height: '10px',
      borderRadius: '50%',
      backgroundColor: active ? '#40c057' : '#ff6b6b',
      boxShadow: active ? '0 0 5px #40c057' : '0 0 5px #ff6b6b'
    }),
    value: {
      color: '#fff',
      fontWeight: 500
    }
  };

  return (
    <div>
      <div style={styles.row}>
        <span style={styles.label}>GPS</span>
        <div style={styles.valueWrapper}>
          <div style={styles.dot(status.gps_connected)} />
          <span style={styles.value}>{status.gps_port || 'N/A'}</span>
        </div>
      </div>
      
      <div style={styles.row}>
        <span style={styles.label}>ESP32</span>
        <div style={styles.valueWrapper}>
          <div style={styles.dot(status.esp_connected)} />
          <span style={styles.value}>{status.esp_port || 'N/A'}</span>
        </div>
      </div>

      <div style={styles.row}>
        <span style={styles.label}>Geofence</span>
        <div style={styles.valueWrapper}>
          <span style={styles.value}>{status.geofence_ready ? 'Sẵn sàng' : 'Chưa sẵn sàng'}</span>
        </div>
      </div>

      <div style={styles.row}>
        <span style={styles.label}>Bản đồ</span>
        <div style={styles.valueWrapper}>
          <span style={styles.value}>{status.map_ready ? 'Sẵn sàng' : 'Trống'}</span>
        </div>
      </div>

      <div style={{...styles.row, borderBottom: 'none'}}>
        <span style={styles.label}>Lệnh điều khiển</span>
        <div style={styles.valueWrapper}>
          <span style={{...styles.value, color: status.real_commands_enabled ? '#ff4444' : '#40c057'}}>
            {status.real_commands_enabled ? 'Đã BẬT (Thực)' : 'Mô phỏng'}
          </span>
        </div>
      </div>
    </div>
  );
};
