import React, { useEffect, useState } from 'react';

interface UserDashboardProps {
  username: string;
  csrfToken: string;
  onLogout: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({ username, csrfToken, onLogout }) => {
  const [cameraStatus, setCameraStatus] = useState<any>(null);

  useEffect(() => {
    const fetchCam = async () => {
      try {
        const res = await fetch('/api/v1/camera/status');
        if (res.ok) {
          const data = await res.json();
          setCameraStatus(data);
        }
      } catch (err) {
        console.error('Camera status error', err);
      }
    };
    fetchCam();
    const interval = setInterval(fetchCam, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = async () => {
    try {
      await fetch('/api/v1/auth/logout', {
        method: 'POST',
        headers: {
          'X-CSRF-Token': csrfToken
        }
      });
    } catch (err) {
      console.error('Logout error:', err);
    }
    onLogout();
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'column' as const,
      height: '100vh',
      backgroundColor: '#0a0a0f',
      color: '#ffffff',
      fontFamily: 'sans-serif'
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 2rem',
      backgroundColor: '#12121a',
      borderBottom: '1px solid #2a2a3a'
    },
    headerTitle: {
      margin: 0,
      fontSize: '1.2rem',
      color: '#4dabf7'
    },
    headerUser: {
      display: 'flex',
      alignItems: 'center',
      gap: '1rem'
    },
    logoutBtn: {
      backgroundColor: 'transparent',
      color: '#ff6b6b',
      border: '1px solid #ff6b6b',
      padding: '0.4rem 0.8rem',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '0.9rem'
    },
    content: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem'
    },
    cameraBox: {
      width: '100%',
      maxWidth: '800px',
      aspectRatio: '16/9',
      backgroundColor: '#1a1a24',
      border: '2px dashed #2a2a3a',
      borderRadius: '8px',
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'center',
      justifyContent: 'center',
      color: '#a0a0b0'
    },
    statusText: {
      marginTop: '1rem',
      fontSize: '1.1rem'
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.headerTitle}>IOT Drone Station</h1>
        <div style={styles.headerUser}>
          <span>Xin chào, <strong>{username}</strong> (User)</span>
          <button style={styles.logoutBtn} onClick={handleLogout}>Đăng xuất</button>
        </div>
      </div>

      <div style={styles.content}>
        <div style={styles.cameraBox}>
          <h2>Chưa kết nối camera</h2>
          {cameraStatus && (
            <p style={styles.statusText}>
              Trạng thái: {cameraStatus.connected ? 'Đang hoạt động' : 'Đóng'}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
