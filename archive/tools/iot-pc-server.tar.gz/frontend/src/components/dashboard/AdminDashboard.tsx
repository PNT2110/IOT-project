import React, { useState } from 'react';
import { SystemStatus } from './SystemStatus';
import { PreflightChecks } from './PreflightChecks';
import { GpsPanel } from '../telemetry/GpsPanel';
import { PidCharts } from '../telemetry/PidCharts';
import { Attitude3D } from '../telemetry/Attitude3D';
import { RawMonitor } from '../serial/RawMonitor';
import { GeofenceAlert } from '../safety/GeofenceAlert';
import { LandButton } from '../safety/LandButton';
import type { TelemetryFrame } from '../../api/client';

interface AdminDashboardProps {
  telemetryFrame: TelemetryFrame | null;
  username: string;
  role: string;
  csrfToken: string;
  onLogout: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  telemetryFrame,
  username,
  role,
  csrfToken,
  onLogout
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'serial' | 'history'>('overview');

  const handleLogout = async () => {
    try {
      await fetch('/api/v1/auth/logout', {
        method: 'POST',
        headers: { 'X-CSRF-Token': csrfToken }
      });
    } catch (err) {
      console.error('Logout error:', err);
    }
    onLogout();
  };

  const tf = telemetryFrame;
  const defaultGps = { latitude: 0, longitude: 0, altitude_m: 0, speed_mps: 0, course_deg: 0, satellites: 0, hdop: 99, fix_quality: 0, valid: false, stale: true, raw: '' };
  const defaultPid = { roll: { kp: 0, ki: 0, kd: 0, setpoint: 0, measured: 0, output: 0 }, pitch: { kp: 0, ki: 0, kd: 0, setpoint: 0, measured: 0, output: 0 }, yaw: { kp: 0, ki: 0, kd: 0, setpoint: 0, measured: 0, output: 0 } };
  const defaultGeofence = { status: 'unknown' as const, data_ready: false };

  // Convert null to undefined for GeofenceAlert compatibility
  const geofenceForAlert = tf?.geofence ? {
    ...tf.geofence,
    zone_id: tf.geofence.zone_id ?? undefined,
    zone_name: tf.geofence.zone_name ?? undefined,
    distance_m: tf.geofence.distance_m ?? undefined,
  } : defaultGeofence;

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerLeft}>
          <h1 style={styles.headerTitle}>⬡ IOT Drone Station</h1>
          <span style={styles.modeTag}>{tf?.flight_mode || 'OFFLINE'}</span>
          {tf?.armed && <span style={styles.armedTag}>ARMED</span>}
        </div>
        <div style={styles.headerRight}>
          <span style={styles.username}>{username} ({role})</span>
          <button style={styles.logoutBtn} onClick={handleLogout}>Đăng xuất</button>
        </div>
      </div>

      {/* Main Grid */}
      <div style={styles.mainGrid}>
        {/* Left: Map */}
        <div style={styles.mapPanel}>
          <div style={styles.mapPlaceholder}>
            <div style={{ fontSize: '3rem', opacity: 0.2 }}>🗺️</div>
            <p>Bản đồ MapLibre + PMTiles</p>
            <p style={{ fontSize: '0.75rem', color: '#555' }}>
              Sẽ hiển thị bản đồ TPHCM offline với 2745 vùng cấm/hạn chế
            </p>
            {tf?.gps_connected && tf.gps.valid && (
              <p style={{ color: '#48bb78', marginTop: '0.5rem' }}>
                📍 {tf.gps.latitude?.toFixed(6)}°N, {tf.gps.longitude?.toFixed(6)}°E
              </p>
            )}
          </div>
          {/* Geofence Alert overlay */}
          <div style={styles.geofenceOverlay}>
            <GeofenceAlert geofence={geofenceForAlert} />
          </div>
        </div>

        {/* Right panels */}
        <div style={styles.rightPanel}>
          {/* GPS Panel */}
          <div style={styles.panelBox}>
            <GpsPanel gps={tf?.gps || defaultGps} />
          </div>

          {/* System Status */}
          <div style={styles.panelBox}>
            <SystemStatus />
          </div>

          {/* Attitude 3D */}
          <div style={styles.panelBox}>
            <Attitude3D
              attitude={tf?.attitude || { roll: 0, pitch: 0, yaw: 0 }}
              flightMode={tf?.flight_mode || 'OFFLINE'}
              armed={tf?.armed || false}
            />
          </div>

          {/* PID Charts */}
          <div style={styles.panelBox}>
            <PidCharts pid={tf?.pid || defaultPid} />
          </div>

          {/* Serial Monitor */}
          <div style={styles.panelBox}>
            <RawMonitor />
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div style={styles.bottomBar}>
        <div style={styles.bottomLeft}>
          <PreflightChecks />
        </div>
        <div style={styles.bottomCenter}>
          <GeofenceAlert geofence={geofenceForAlert} />
        </div>
        <div style={styles.bottomRight}>
          <LandButton
            csrfToken={csrfToken}
            armed={tf?.armed || false}
            espConnected={tf?.esp_connected || false}
          />
        </div>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#0a0a0f',
    color: '#e2e8f0',
    fontFamily: 'Inter, ui-sans-serif, system-ui, sans-serif',
    overflow: 'hidden',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0.5rem 1rem',
    backgroundColor: '#12121a',
    borderBottom: '1px solid #2a2a3a',
  },
  headerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
  },
  headerTitle: {
    margin: 0,
    fontSize: '1rem',
    fontWeight: 600,
    color: '#e2e8f0',
    letterSpacing: '-0.02em',
  },
  modeTag: {
    fontSize: '0.7rem',
    fontWeight: 700,
    padding: '0.15rem 0.5rem',
    borderRadius: '3px',
    backgroundColor: '#1a2a3a',
    color: '#4a9eff',
    letterSpacing: '0.05em',
  },
  armedTag: {
    fontSize: '0.7rem',
    fontWeight: 700,
    padding: '0.15rem 0.5rem',
    borderRadius: '3px',
    backgroundColor: '#3a1515',
    color: '#fc5c65',
    letterSpacing: '0.05em',
    animation: 'pulse 1.5s infinite',
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
  },
  username: {
    fontSize: '0.84rem',
    color: '#8892a8',
  },
  logoutBtn: {
    backgroundColor: 'transparent',
    color: '#fc5c65',
    border: '1px solid #fc5c65',
    padding: '0.3rem 0.6rem',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '0.8rem',
  },
  mainGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 380px',
    gap: '1px',
    flex: 1,
    minHeight: 0,
    overflow: 'hidden',
    background: '#2a2a3a',
  },
  mapPanel: {
    position: 'relative',
    backgroundColor: '#0a0a0f',
    overflow: 'hidden',
  },
  mapPlaceholder: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    color: '#555',
    fontSize: '0.85rem',
  },
  geofenceOverlay: {
    position: 'absolute',
    top: '0.5rem',
    right: '0.5rem',
    zIndex: 10,
  },
  rightPanel: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1px',
    overflowY: 'auto',
    backgroundColor: '#2a2a3a',
  },
  panelBox: {
    backgroundColor: '#0a0a0f',
    padding: '0.65rem',
  },
  bottomBar: {
    display: 'grid',
    gridTemplateColumns: 'auto 1fr auto',
    gap: '1rem',
    padding: '0.4rem 1rem',
    backgroundColor: '#12121a',
    borderTop: '1px solid #2a2a3a',
    alignItems: 'center',
  },
  bottomLeft: {},
  bottomCenter: {
    textAlign: 'center',
  },
  bottomRight: {},
};
