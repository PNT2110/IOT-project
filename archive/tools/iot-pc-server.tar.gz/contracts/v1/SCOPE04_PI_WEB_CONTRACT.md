# SCOPE-04 Pi Web Contract v1

Status: `PC_REPO_IMPLEMENTED`; live Pi deployment: `NOT_RUN`.

This is a Pi-local, read-only contract. The identity domain is separate from
the PC server. `source=MOCK` is explicit for mock telemetry. Missing values
are `null` and rendered as `UNAVAILABLE`; they are never generated from
random animation or inferred device state.

Implemented read-only routes:

```text
GET  /health
POST /api/pi/v1/auth/challenge
POST /api/pi/v1/auth/login
GET  /api/pi/v1/auth/me
POST /api/pi/v1/auth/logout          (CSRF protected)
GET  /api/pi/v1/camera/status        (authenticated)
GET  /api/pi/v1/camera/stream        (authenticated, one bounded local frame)
GET  /api/pi/v1/map/cache            (authenticated)
GET  /api/pi/v1/telemetry            (authenticated)
GET  /api/pi/v1/3d                   (authenticated)
```

There are deliberately no ARM, DISARM, motor, relay, firmware, PC-sync, or
public-bind routes in this contract. Camera default is `/dev/video0`;
`/dev/video1` is rejected by the adapter because the inventory identifies it
as the metadata node.
