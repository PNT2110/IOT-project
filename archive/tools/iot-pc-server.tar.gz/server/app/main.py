from __future__ import annotations

import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .api import build_router
from .config import Settings, load_settings
from .db import make_engine, make_session_factory
from .mail import FakeEmailSender
from .models import Base
from .services import seed_demo_zones


def create_app(settings: Settings | None = None, *, initialize_schema: bool = False) -> FastAPI:
    settings = settings or load_settings()
    engine = make_engine(settings.database_url)
    factory = make_session_factory(engine)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if initialize_schema:
            Base.metadata.create_all(engine)
        try:
            with factory() as db:
                seed_demo_zones(db)
        except Exception:
            # Startup must not silently create a schema in normal mode. The README requires migration first.
            if initialize_schema:
                raise
        yield
        engine.dispose()

    app = FastAPI(title="IOT Research Prototype — PC Foundation", version="0.1.0", lifespan=lifespan)
    app.state.settings = settings
    app.state.session_factory = factory
    app.state.fake_mail = FakeEmailSender(settings.fake_mail_outbox)
    app.state.factor_failures = {}
    app.add_middleware(CORSMiddleware, allow_origins=list(settings.allowed_origins), allow_credentials=True, allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"], allow_headers=["Authorization", "Content-Type", "If-Match", "X-CSRF-Token", "X-Request-ID"])

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        request.state.request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        return response

    @app.exception_handler(HTTPException)
    async def http_error_handler(request: Request, exc: HTTPException):
        detail = exc.detail if isinstance(exc.detail, dict) else {"code": "HTTP_ERROR", "message_for_user": str(exc.detail)}
        return JSONResponse(status_code=exc.status_code, content={"schema_version": "v1", "request_id": getattr(request.state, "request_id", ""), "data": None, "error": detail, "observed_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()})

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError):
        return JSONResponse(status_code=422, content={"schema_version": "v1", "request_id": getattr(request.state, "request_id", ""), "data": None, "error": {"code": "VALIDATION_ERROR", "message_for_user": str(exc)}, "observed_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()})

    app.include_router(build_router())
    return app


# Uvicorn loads this object after the operator supplies SESSION_SECRET. Keeping
# import-time configuration lazy allows isolated unit tests to use create_app()
# with an explicit Settings object without manufacturing a default secret.
app = create_app() if __import__("os").getenv("SESSION_SECRET") else None
