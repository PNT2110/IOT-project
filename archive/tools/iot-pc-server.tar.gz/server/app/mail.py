from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path


@dataclass(frozen=True)
class FakeMail:
    recipient: str
    purpose: str
    code: str
    sent_at: datetime


class FakeEmailSender:
    """In-memory dev/test sink; never enabled as a real email provider."""

    def __init__(self, outbox_path: str | None = None) -> None:
        self.messages: list[FakeMail] = []
        self.outbox_path = Path(outbox_path) if outbox_path else None

    def send_code(self, recipient: str, purpose: str, code: str, sent_at: datetime) -> None:
        self.messages.append(FakeMail(recipient, purpose, code, sent_at))
        if self.outbox_path:
            self.outbox_path.parent.mkdir(parents=True, exist_ok=True)
            with self.outbox_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps({"recipient": recipient, "purpose": purpose, "code": code, "sent_at": sent_at.isoformat()}) + "\n")

    def latest(self, recipient: str | None = None, purpose: str | None = None) -> FakeMail | None:
        for message in reversed(self.messages):
            if recipient and message.recipient != recipient:
                continue
            if purpose and message.purpose != purpose:
                continue
            return message
        return None
