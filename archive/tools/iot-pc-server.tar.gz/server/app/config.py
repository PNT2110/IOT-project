from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def _csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


@dataclass(frozen=True)
class Settings:
    app_env: str
    database_url: str
    session_secret: str
    cookie_secure: bool
    allowed_origins: tuple[str, ...]
    host: str
    port: int
    fake_mail_outbox: str | None = None
    session_ttl_minutes: int = 60
    challenge_ttl_minutes: int = 10
    max_zone_bytes: int = 200_000


def load_settings() -> Settings:
    env = os.getenv("APP_ENV", "development")
    secret = os.getenv("SESSION_SECRET")
    if not secret:
        raise RuntimeError("SESSION_SECRET is required; provide it via the environment")
    database_url = os.getenv("DATABASE_URL", f"sqlite:///{ROOT / 'server' / 'data' / 'app.db'}")
    return Settings(
        app_env=env,
        database_url=database_url,
        session_secret=secret,
        cookie_secure=os.getenv("COOKIE_SECURE", "true").lower() == "true",
        allowed_origins=tuple(_csv(os.getenv("ALLOWED_ORIGINS", "https://localhost:5173"))),
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8765")),
        fake_mail_outbox=os.getenv("FAKE_MAIL_OUTBOX") or None,
    )
