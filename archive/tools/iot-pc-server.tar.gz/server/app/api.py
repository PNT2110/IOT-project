from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import Settings
from .db import get_db
from .geo import GeometryError, validate_polygon_geojson
from .models import (
    Credential,
    EmailChallenge,
    IdempotencyRecord,
    RecoveryCode,
    RoleElevationRequest,
    SessionRecord,
    SimulatedFlightRequest,
    TermsAcceptance,
    User,
    Zone,
    ZoneSource,
    AuditEvent,
    CapabilityGrant,
    WorkflowHistory,
)
from .schemas import (
    CodeRequest,
    EnrollmentCodeRequest,
    AccountStatusRequest,
    CapabilityGrantCreateRequest,
    CapabilityGrantRevokeRequest,
    LoginRequest,
    RecoveryRequest,
    RegisterRequest,
    RoleElevationCreateRequest,
    RoleElevationDecisionRequest,
    SimulatedFlightActionRequest,
    SimulatedFlightCreateRequest,
    SimulatedFlightDecisionRequest,
    ZoneCreateRequest,
    ZoneUpdateRequest,
    ok,
)
from .security import (
    decrypt_secret,
    digest_token,
    encrypt_secret,
    hash_password,
    new_recovery_code,
    new_token,
    new_totp_secret,
    normalize_email,
    as_utc,
    totp_at,
    utcnow,
    verify_password,
)
from .services import ACCOUNT_APPROVE, ADMIN_ROLE_APPROVE, PC_GUEST_SCOPE, create_email_code, has_active_capability, payload_digest, record_audit, record_history


def _now_iso() -> str:
    return utcnow().isoformat()


def _db(request: Request):
    yield from get_db(request.app.state.session_factory)


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _mail(request: Request):
    return request.app.state.fake_mail


def _token_from_request(request: Request) -> str | None:
    authorization = request.headers.get("authorization", "")
    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return request.cookies.get("session")


def _session(request: Request, db: Session, required_stage: str | None = "AUTHENTICATED") -> tuple[SessionRecord, User, str]:
    token = _token_from_request(request)
    if not token:
        raise HTTPException(status_code=401, detail={"code": "AUTH_REQUIRED", "message_for_user": "Authentication required"})
    settings = request.app.state.settings
    record = db.scalar(select(SessionRecord).where(SessionRecord.token_digest == digest_token(settings.session_secret, token)))
    if not record or record.revoked_at or as_utc(record.expires_at) <= utcnow():
        raise HTTPException(status_code=401, detail={"code": "SESSION_INVALID", "message_for_user": "Session is invalid or expired"})
    if required_stage and record.stage != required_stage:
        raise HTTPException(status_code=403, detail={"code": "MFA_INCOMPLETE", "message_for_user": "Authentication steps are incomplete"})
    user = db.get(User, record.user_id)
    if not user:
        raise HTTPException(status_code=401, detail={"code": "SESSION_INVALID", "message_for_user": "Session is invalid"})
    if user.status in {"REJECTED", "SUSPENDED"} and record.stage == "AUTHENTICATED":
        record.revoked_at = utcnow()
        db.commit()
        raise HTTPException(status_code=401, detail={"code": "SESSION_REVOKED", "message_for_user": "Session is no longer active"})
    record.last_seen_at = utcnow()
    return record, user, token


def _staged_session(request: Request, db: Session, stage: str) -> tuple[SessionRecord, User, str]:
    return _session(request, db, required_stage=stage)


def _require_map_read(request: Request, db: Session) -> tuple[SessionRecord, User, str]:
    record, user, token = _session(request, db)
    if user.status != "ACTIVE" or user.role not in {"OPERATOR", "ADMIN", "OWNER"}:
        raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Internal map access is not available"})
    return record, user, token


def _require_map_write(request: Request, db: Session) -> tuple[SessionRecord, User, str]:
    record, user, token = _require_map_read(request, db)
    if user.role not in {"ADMIN", "OWNER"}:
        raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Map write access is restricted"})
    return record, user, token


def _challenge_or_error(db: Session, challenge_id: str, settings: Settings, code: str) -> EmailChallenge:
    challenge = db.get(EmailChallenge, challenge_id)
    if not challenge or challenge.used_at or as_utc(challenge.expires_at) <= utcnow() or challenge.attempts >= challenge.max_attempts:
        raise HTTPException(status_code=400, detail={"code": "CHALLENGE_INVALID", "message_for_user": "Challenge is invalid or expired"})
    challenge.attempts += 1
    if digest_token(settings.session_secret, code, salt=challenge.user_id) != challenge.code_digest:
        # Persist failed attempts so the challenge-level rate limit cannot be
        # bypassed by rolling back the request transaction.
        db.commit()
        raise HTTPException(status_code=400, detail={"code": "CODE_INVALID", "message_for_user": "Code is invalid"})
    challenge.used_at = utcnow()
    return challenge


def _set_auth_cookies(response: Response, settings: Settings, token: str, csrf: str) -> None:
    response.set_cookie("session", token, httponly=True, secure=settings.cookie_secure, samesite="lax", max_age=settings.session_ttl_minutes * 60, path="/")
    response.set_cookie("csrf", csrf, httponly=False, secure=settings.cookie_secure, samesite="lax", max_age=settings.session_ttl_minutes * 60, path="/")


def _require_csrf(request: Request, record: SessionRecord, settings: Settings) -> None:
    if request.method in {"GET", "HEAD", "OPTIONS"}:
        return
    if request.headers.get("authorization", "").lower().startswith("bearer "):
        return
    csrf = request.headers.get("x-csrf-token")
    if not csrf or digest_token(settings.session_secret, csrf) != record.csrf_digest:
        raise HTTPException(status_code=403, detail={"code": "CSRF_REQUIRED", "message_for_user": "CSRF token required"})


def _factor_rate_limit_check(request: Request, record: SessionRecord) -> None:
    if request.app.state.factor_failures.get(record.id, 0) >= 5:
        raise HTTPException(status_code=429, detail={"code": "FACTOR_RATE_LIMITED", "message_for_user": "Too many invalid factor attempts"})


def _factor_failure(request: Request, record: SessionRecord) -> None:
    failures = request.app.state.factor_failures
    failures[record.id] = failures.get(record.id, 0) + 1


def _require_owner(request: Request, db: Session) -> tuple[SessionRecord, User, str]:
    record, user, token = _session(request, db)
    if user.status != "ACTIVE" or user.role != "OWNER" or not user.credential or not user.credential.totp_active:
        raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Owner review access is required"})
    return record, user, token


def _require_account_status_reviewer(request: Request, db: Session) -> tuple[SessionRecord, User, str]:
    record, user, token = _session(request, db)
    if user.status != "ACTIVE" or not user.credential or not user.credential.totp_active:
        raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Active MFA review access is required"})
    if user.role == "OWNER" or (user.role == "ADMIN" and has_active_capability(db, user_id=user.id, action=ACCOUNT_APPROVE)):
        return record, user, token
    raise HTTPException(status_code=403, detail={"code": "CAPABILITY_REQUIRED", "message_for_user": "Owner-granted account approval capability is required"})


def _require_role_reviewer(request: Request, db: Session) -> tuple[SessionRecord, User, str]:
    record, user, token = _session(request, db)
    if user.status != "ACTIVE" or not user.credential or not user.credential.totp_active:
        raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Active MFA review access is required"})
    if user.role == "OWNER" or (user.role == "ADMIN" and has_active_capability(db, user_id=user.id, action=ADMIN_ROLE_APPROVE)):
        return record, user, token
    raise HTTPException(status_code=403, detail={"code": "CAPABILITY_REQUIRED", "message_for_user": "Owner-granted role approval capability is required"})


def _effective_review_capabilities(db: Session, user: User) -> dict:
    active_mfa = user.status == "ACTIVE" and bool(user.credential and user.credential.totp_active)
    owner = active_mfa and user.role == "OWNER"
    account_approve = owner or (active_mfa and user.role == "ADMIN" and has_active_capability(db, user_id=user.id, action=ACCOUNT_APPROVE))
    admin_role_approve = owner or (active_mfa and user.role == "ADMIN" and has_active_capability(db, user_id=user.id, action=ADMIN_ROLE_APPROVE))
    return {
        "policy": "OWNER_OR_GRANTED_ADMIN_SCOPED",
        "role": user.role,
        "status": user.status,
        "can_approve_accounts": account_approve,
        "can_approve_admin_role": admin_role_approve,
        "account_approve": {
            "allowed": account_approve,
            "scope": "ALL_ACCOUNT_STATUS_TRANSITIONS_EXCEPT_SELF" if owner else "PENDING_PC_GUEST_TO_ACTIVE" if account_approve else "NONE",
        },
        "admin_role_approve": {
            "allowed": admin_role_approve,
            "scope": "ALL_ROLE_ELEVATIONS_EXCEPT_SELF" if owner else "ACTIVE_PC_GUEST_TO_ADMIN_APPROVE_ONLY" if admin_role_approve else "NONE",
        },
    }


def _require_workflow_reviewer(request: Request, db: Session) -> tuple[SessionRecord, User, str]:
    record, user, token = _session(request, db)
    if user.status != "ACTIVE" or user.role not in {"OPERATOR", "ADMIN", "OWNER"}:
        raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Workflow review access is not available"})
    return record, user, token


def _require_active_user(request: Request, db: Session) -> tuple[SessionRecord, User, str]:
    record, user, token = _session(request, db)
    if user.status != "ACTIVE":
        raise HTTPException(status_code=403, detail={"code": "ACCOUNT_NOT_ACTIVE", "message_for_user": "Account approval is required"})
    return record, user, token


def _parse_if_match(if_match: str | None, *, required: bool = True) -> int | None:
    if if_match is None:
        if required:
            raise HTTPException(status_code=428, detail={"code": "IF_MATCH_REQUIRED", "message_for_user": "If-Match is required"})
        return None
    try:
        return int(if_match.strip('"'))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail={"code": "IF_MATCH_INVALID", "message_for_user": "If-Match must be an integer version"}) from exc


def _require_idempotency_key(value: str | None) -> str:
    if not value or len(value) > 128 or not value.strip():
        raise HTTPException(status_code=400, detail={"code": "IDEMPOTENCY_KEY_REQUIRED", "message_for_user": "Idempotency-Key is required"})
    return value.strip()


def _idempotency_replay(db: Session, *, actor_user_id: str, key: str, digest: str):
    existing = db.scalar(select(IdempotencyRecord).where(IdempotencyRecord.actor_user_id == actor_user_id, IdempotencyRecord.idempotency_key == key))
    if not existing:
        return None
    if existing.payload_digest != digest:
        raise HTTPException(status_code=409, detail={"code": "IDEMPOTENCY_KEY_REUSE", "message_for_user": "Idempotency key was already used with different data"})
    return existing


def _remember_idempotency(db: Session, *, actor_user_id: str, key: str, action: str, object_type: str, object_id: str | None, digest: str, data: dict, status_code: int = 200) -> None:
    db.add(IdempotencyRecord(actor_user_id=actor_user_id, idempotency_key=key, action=action, object_type=object_type, object_id=object_id, payload_digest=digest, response_json=json.dumps(data, sort_keys=True), status_code=status_code, created_at=utcnow()))


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat() if value.tzinfo else value.replace(tzinfo=timezone.utc).isoformat()


def _account_view(user: User) -> dict:
    return {"id": user.id, "display_name": user.display_name, "email": user.email_normalized, "status": user.status, "role": user.role, "version": user.version, "email_verified": bool(user.email_verified_at), "created_at": _iso(user.created_at), "updated_at": _iso(user.updated_at)}


def _elevation_view(item: RoleElevationRequest) -> dict:
    return {"id": item.id, "requester_user_id": item.requester_user_id, "requested_role": item.requested_role, "status": item.status, "reason": item.reason, "reviewer_user_id": item.reviewer_user_id, "reviewer_reason": item.reviewer_reason, "reviewed_at": _iso(item.reviewed_at) if item.reviewed_at else None, "version": item.version, "created_at": _iso(item.created_at), "updated_at": _iso(item.updated_at)}


def _flight_view(item: SimulatedFlightRequest) -> dict:
    return {"id": item.id, "submitter_user_id": item.submitter_user_id, "summary": item.summary, "scheduled_start_at": _iso(item.scheduled_start_at), "scheduled_end_at": _iso(item.scheduled_end_at), "geometry": json.loads(item.simulated_geometry_json), "status": item.status, "version": item.version, "simulated": True, "label": "SIMULATED — NOT A FLIGHT PERMIT", "source": item.source, "updated_at": _iso(item.updated_at), "created_at": _iso(item.created_at)}


def _history_view(item: WorkflowHistory) -> dict:
    return {"id": item.id, "actor_user_id": item.actor_user_id, "object_type": item.object_type, "object_id": item.object_id, "action": item.action, "from_state": item.from_state, "to_state": item.to_state, "from_version": item.from_version, "to_version": item.to_version, "reason": item.reason, "request_id": item.request_id, "metadata": json.loads(item.metadata_redacted or "{}"), "created_at": _iso(item.created_at)}


def _grant_view(item: CapabilityGrant) -> dict:
    return {"id": item.id, "grantor_user_id": item.grantor_user_id, "grantee_user_id": item.grantee_user_id, "actions": sorted(json.loads(item.actions_json or "[]")), "resource_scope": item.resource_scope, "reason": item.reason, "version": item.version, "created_at": _iso(item.created_at), "revoked_at": _iso(item.revoked_at) if item.revoked_at else None, "revoked_by_user_id": item.revoked_by_user_id, "revoked_reason": item.revoked_reason}


def build_router() -> APIRouter:
    router = APIRouter(prefix="/api/v1")

    @router.get("/health")
    def health(request: Request):
        return ok({"status": "ok", "environment": request.app.state.settings.app_env, "local_only": True}, request.state.request_id, _now_iso())

    @router.post("/auth/register", status_code=201)
    def register(body: RegisterRequest, request: Request, db: Session = Depends(_db), settings: Settings = Depends(_settings), mail=Depends(_mail)):
        email = normalize_email(str(body.email))
        if db.scalar(select(User).where(User.email_normalized == email)):
            raise HTTPException(status_code=409, detail={"code": "EMAIL_IN_USE", "message_for_user": "An account with this email already exists"})
        now = utcnow()
        user = User(display_name=body.display_name.strip(), email_normalized=email, status="PENDING", role="GUEST", created_at=now, updated_at=now)
        user.credential = Credential(password_hash=hash_password(body.password), created_at=now, updated_at=now)
        db.add(user)
        db.flush()
        if not db.scalar(select(TermsAcceptance).where(TermsAcceptance.user_id == user.id, TermsAcceptance.terms_version == body.terms_version)):
            db.add(TermsAcceptance(user_id=user.id, terms_version=body.terms_version, accepted_at=now))
        challenge = create_email_code(db, settings, mail, user_id=user.id, email=email, purpose="VERIFY_EMAIL")
        record_audit(db, actor_user_id=None, action="REGISTER", object_type="USER", object_id=user.id, outcome="SUCCESS", request_id=request.state.request_id)
        db.commit()
        return ok({"challenge_id": challenge.id, "next_step": "VERIFY_EMAIL", "status": "PENDING"}, request.state.request_id, _now_iso())

    @router.post("/auth/verify-email")
    def verify_email(body: CodeRequest, request: Request, db: Session = Depends(_db), settings: Settings = Depends(_settings)):
        challenge = _challenge_or_error(db, body.challenge_id, settings, body.code)
        if challenge.purpose != "VERIFY_EMAIL":
            raise HTTPException(status_code=400, detail={"code": "CHALLENGE_WRONG_FLOW", "message_for_user": "Challenge is not an email verification challenge"})
        user = db.get(User, challenge.user_id)
        user.email_verified_at = utcnow()
        token = new_token()
        csrf = new_token()
        db.add(SessionRecord(token_digest=digest_token(settings.session_secret, token), user_id=user.id, stage="MFA_ENROLLMENT", csrf_digest=digest_token(settings.session_secret, csrf), expires_at=utcnow() + timedelta(minutes=settings.session_ttl_minutes), last_seen_at=utcnow(), created_at=utcnow()))
        db.commit()
        return ok({"enrollment_token": token, "next_step": "TOTP_ENROLLMENT"}, request.state.request_id, _now_iso())

    @router.post("/auth/mfa/enroll")
    def enroll_mfa(request: Request, db: Session = Depends(_db), settings: Settings = Depends(_settings)):
        record, user, _ = _staged_session(request, db, "MFA_ENROLLMENT")
        if not user.email_verified_at:
            raise HTTPException(status_code=403, detail={"code": "EMAIL_NOT_VERIFIED", "message_for_user": "Email verification is required"})
        if user.credential.totp_secret_encrypted:
            raise HTTPException(status_code=409, detail={"code": "TOTP_ALREADY_ENROLLED", "message_for_user": "TOTP enrollment already started"})
        secret = new_totp_secret()
        user.credential.totp_secret_encrypted = encrypt_secret(settings.session_secret, secret)
        db.commit()
        uri = __import__("pyotp").TOTP(secret).provisioning_uri(name=user.email_normalized, issuer_name="IOT Research Prototype")
        return ok({"secret": secret, "otpauth_uri": uri, "warning": "Display once; never log or store in client persistence"}, request.state.request_id, _now_iso())

    @router.post("/auth/mfa/confirm")
    def confirm_mfa(body: EnrollmentCodeRequest, request: Request, response: Response, db: Session = Depends(_db), settings: Settings = Depends(_settings)):
        record, user, token = _staged_session(request, db, "MFA_ENROLLMENT")
        _factor_rate_limit_check(request, record)
        secret = decrypt_secret(settings.session_secret, user.credential.totp_secret_encrypted or "")
        valid, step = totp_at(secret, body.code)
        if not valid:
            _factor_failure(request, record)
            raise HTTPException(status_code=400, detail={"code": "TOTP_INVALID", "message_for_user": "TOTP code is invalid or already used"})
        user.credential.totp_active = True
        user.credential.totp_last_step = step
        codes = []
        for _ in range(8):
            code = new_recovery_code()
            codes.append(code)
            db.add(RecoveryCode(user_id=user.id, code_digest=digest_token(settings.session_secret, code, salt=user.id), created_at=utcnow()))
        record.stage = "AUTHENTICATED"
        csrf = new_token()
        record.csrf_digest = digest_token(settings.session_secret, csrf)
        db.commit()
        request.app.state.factor_failures.pop(record.id, None)
        _set_auth_cookies(response, settings, token, csrf)
        return ok({"status": "PENDING", "role": user.role, "recovery_codes": codes, "warning": "Recovery codes are shown once"}, request.state.request_id, _now_iso())

    @router.post("/auth/login")
    def login(body: LoginRequest, request: Request, db: Session = Depends(_db), settings: Settings = Depends(_settings), mail=Depends(_mail)):
        email = normalize_email(str(body.email))
        user = db.scalar(select(User).where(User.email_normalized == email))
        if not user or not user.credential or not verify_password(user.credential.password_hash, body.password):
            raise HTTPException(status_code=401, detail={"code": "AUTH_FAILED", "message_for_user": "Authentication failed"})
        if user.status in {"REJECTED", "SUSPENDED"}:
            raise HTTPException(status_code=403, detail={"code": "ACCOUNT_NOT_ACTIVE", "message_for_user": "Account is not active"})
        if not user.email_verified_at or not user.credential.totp_active:
            raise HTTPException(status_code=403, detail={"code": "MFA_NOT_READY", "message_for_user": "Account MFA setup is incomplete"})
        now = utcnow()
        if not db.scalar(select(TermsAcceptance).where(TermsAcceptance.user_id == user.id, TermsAcceptance.terms_version == body.terms_version)):
            db.add(TermsAcceptance(user_id=user.id, terms_version=body.terms_version, accepted_at=now))
        token = new_token()
        csrf = new_token()
        session = SessionRecord(token_digest=digest_token(settings.session_secret, token), user_id=user.id, stage="EMAIL_OTP", terms_version=body.terms_version, csrf_digest=digest_token(settings.session_secret, csrf), expires_at=now + timedelta(minutes=settings.session_ttl_minutes), last_seen_at=now, created_at=now)
        db.add(session)
        challenge = create_email_code(db, settings, mail, user_id=user.id, email=email, purpose="LOGIN_OTP")
        db.commit()
        return ok({"login_token": token, "challenge_id": challenge.id, "next_step": "EMAIL_OTP"}, request.state.request_id, _now_iso())

    @router.post("/auth/verify-login-otp")
    def verify_login_otp(body: CodeRequest, request: Request, db: Session = Depends(_db), settings: Settings = Depends(_settings)):
        record, user, token = _staged_session(request, db, "EMAIL_OTP")
        if body.challenge_id not in {c.id for c in db.scalars(select(EmailChallenge).where(EmailChallenge.user_id == user.id, EmailChallenge.purpose == "LOGIN_OTP"))}:
            raise HTTPException(status_code=400, detail={"code": "CHALLENGE_WRONG_FLOW", "message_for_user": "Challenge is not valid for this session"})
        challenge = _challenge_or_error(db, body.challenge_id, settings, body.code)
        record.stage = "TOTP"
        db.commit()
        return ok({"login_token": token, "next_step": "TOTP"}, request.state.request_id, _now_iso())

    @router.post("/auth/verify-totp")
    def verify_login_totp(body: EnrollmentCodeRequest, request: Request, response: Response, db: Session = Depends(_db), settings: Settings = Depends(_settings)):
        record, user, token = _staged_session(request, db, "TOTP")
        _factor_rate_limit_check(request, record)
        secret = decrypt_secret(settings.session_secret, user.credential.totp_secret_encrypted or "")
        valid, step = totp_at(secret, body.code, user.credential.totp_last_step)
        if not valid:
            _factor_failure(request, record)
            raise HTTPException(status_code=400, detail={"code": "TOTP_INVALID", "message_for_user": "TOTP code is invalid or already used"})
        user.credential.totp_last_step = step
        record.stage = "AUTHENTICATED"
        csrf = new_token()
        record.csrf_digest = digest_token(settings.session_secret, csrf)
        db.commit()
        request.app.state.factor_failures.pop(record.id, None)
        _set_auth_cookies(response, settings, token, csrf)
        return ok({"access_token": token, "role": user.role, "status": user.status, "next_step": "AUTHENTICATED"}, request.state.request_id, _now_iso())

    @router.post("/auth/recovery")
    def recovery(body: RecoveryRequest, request: Request, response: Response, db: Session = Depends(_db), settings: Settings = Depends(_settings)):
        record, user, token = _staged_session(request, db, "TOTP")
        digest = digest_token(settings.session_secret, body.code, salt=user.id)
        code_row = db.scalar(select(RecoveryCode).where(RecoveryCode.user_id == user.id, RecoveryCode.code_digest == digest, RecoveryCode.used_at.is_(None)))
        if not code_row:
            raise HTTPException(status_code=400, detail={"code": "RECOVERY_INVALID", "message_for_user": "Recovery code is invalid or already used"})
        code_row.used_at = utcnow()
        record.stage = "AUTHENTICATED"
        csrf = new_token()
        record.csrf_digest = digest_token(settings.session_secret, csrf)
        db.commit()
        _set_auth_cookies(response, settings, token, csrf)
        return ok({"access_token": token, "role": user.role, "status": user.status, "next_step": "AUTHENTICATED"}, request.state.request_id, _now_iso())

    @router.get("/auth/me")
    def me(request: Request, db: Session = Depends(_db)):
        _, user, _ = _session(request, db)
        return ok({"id": user.id, "display_name": user.display_name, "email": user.email_normalized, "status": user.status, "role": user.role}, request.state.request_id, _now_iso())

    @router.post("/auth/logout")
    def logout(request: Request, response: Response, db: Session = Depends(_db), settings: Settings = Depends(_settings)):
        record, _, _ = _session(request, db)
        _require_csrf(request, record, settings)
        record.revoked_at = utcnow()
        db.commit()
        response.delete_cookie("session", path="/")
        response.delete_cookie("csrf", path="/")
        return ok({"logged_out": True}, request.state.request_id, _now_iso())

    @router.get("/public/zones")
    def public_zones(request: Request, db: Session = Depends(_db)):
        rows = db.scalars(select(Zone).where(Zone.visibility == "PUBLIC", Zone.deleted_at.is_(None)).order_by(Zone.name)).all()
        data = [{"id": z.id, "name": z.name, "geometry": json.loads(z.geometry_json), "visibility": "PUBLIC", "classification": "DEMO", "version": z.version, "retrieved_at": z.retrieved_at.isoformat()} for z in rows]
        return ok({"items": data, "count": len(data), "label": "SIMULATED — NOT OFFICIAL AIRSPACE DATA"}, request.state.request_id, _now_iso())

    @router.get("/internal/zones")
    def internal_zones(request: Request, db: Session = Depends(_db)):
        _require_map_read(request, db)
        rows = db.scalars(select(Zone).where(Zone.deleted_at.is_(None)).order_by(Zone.name)).all()
        data = [{"id": z.id, "name": z.name, "geometry": json.loads(z.geometry_json), "visibility": z.visibility, "classification": z.classification, "source_id": z.source_id, "version": z.version, "retrieved_at": z.retrieved_at.isoformat()} for z in rows]
        return ok({"items": data, "count": len(data), "label": "SIMULATED — NOT OFFICIAL AIRSPACE DATA"}, request.state.request_id, _now_iso())

    @router.post("/internal/zones", status_code=201)
    def create_zone(body: ZoneCreateRequest, request: Request, db: Session = Depends(_db)):
        _, user, _ = _require_map_write(request, db)
        try:
            geometry = validate_polygon_geojson(body.geometry, request.app.state.settings.max_zone_bytes)
        except GeometryError as exc:
            raise HTTPException(status_code=422, detail={"code": "INVALID_GEOMETRY", "message_for_user": str(exc)}) from exc
        source = db.get(ZoneSource, body.source_id)
        if not source:
            raise HTTPException(status_code=422, detail={"code": "SOURCE_NOT_FOUND", "message_for_user": "Zone source does not exist"})
        now = utcnow()
        zone = Zone(name=body.name, source_id=source.id, geometry_json=json.dumps(geometry, separators=(",", ":")), visibility=body.visibility, classification=body.classification, version=1, retrieved_at=now, created_at=now, updated_at=now)
        db.add(zone)
        db.flush()
        record_audit(db, actor_user_id=user.id, action="CREATE", object_type="ZONE", object_id=zone.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"version": 1, "visibility": zone.visibility})
        db.commit()
        return ok({"id": zone.id, "version": zone.version}, request.state.request_id, _now_iso())

    @router.patch("/internal/zones/{zone_id}")
    def update_zone(zone_id: str, body: ZoneUpdateRequest, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match")):
        _, user, _ = _require_map_write(request, db)
        zone = db.get(Zone, zone_id)
        if not zone or zone.deleted_at:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Zone not found"})
        expected = body.version if not if_match else int(if_match.strip('"'))
        if expected != zone.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Zone version has changed"})
        try:
            geometry = validate_polygon_geojson(body.geometry, request.app.state.settings.max_zone_bytes)
        except (GeometryError, ValueError) as exc:
            raise HTTPException(status_code=422, detail={"code": "INVALID_GEOMETRY", "message_for_user": str(exc)}) from exc
        if not db.get(ZoneSource, body.source_id):
            raise HTTPException(status_code=422, detail={"code": "SOURCE_NOT_FOUND", "message_for_user": "Zone source does not exist"})
        zone.name = body.name
        zone.geometry_json = json.dumps(geometry, separators=(",", ":"))
        zone.visibility = body.visibility
        zone.classification = body.classification
        zone.source_id = body.source_id
        zone.version += 1
        zone.updated_at = utcnow()
        record_audit(db, actor_user_id=user.id, action="UPDATE", object_type="ZONE", object_id=zone.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_version": expected, "to_version": zone.version})
        db.commit()
        return ok({"id": zone.id, "version": zone.version}, request.state.request_id, _now_iso())

    @router.delete("/internal/zones/{zone_id}")
    def delete_zone(zone_id: str, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match")):
        _, user, _ = _require_map_write(request, db)
        zone = db.get(Zone, zone_id)
        if not zone or zone.deleted_at:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Zone not found"})
        if if_match is None:
            raise HTTPException(status_code=428, detail={"code": "IF_MATCH_REQUIRED", "message_for_user": "If-Match is required"})
        try:
            expected = int(if_match.strip('"'))
        except ValueError as exc:
            raise HTTPException(status_code=422, detail={"code": "IF_MATCH_INVALID", "message_for_user": "If-Match must be an integer version"}) from exc
        if expected != zone.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Zone version has changed"})
        zone.deleted_at = utcnow()
        zone.version += 1
        record_audit(db, actor_user_id=user.id, action="DELETE", object_type="ZONE", object_id=zone.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_version": expected, "to_version": zone.version})
        db.commit()
        return ok({"id": zone.id, "deleted": True, "version": zone.version}, request.state.request_id, _now_iso())

    @router.post("/account-review/grants", status_code=201)
    def create_capability_grant(body: CapabilityGrantCreateRequest, request: Request, db: Session = Depends(_db), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, owner, _ = _require_owner(request, db)
        target = db.get(User, body.grantee_user_id)
        if not target or target.status != "ACTIVE" or target.role != "ADMIN" or target.id == owner.id:
            raise HTTPException(status_code=422, detail={"code": "INVALID_GRANTEE", "message_for_user": "Capability must target another active PC Admin"})
        key = _require_idempotency_key(idempotency_key)
        actions = sorted(set(body.actions))
        digest = payload_digest({"action": "CREATE_CAPABILITY_GRANT", "grantee_user_id": target.id, "actions": actions, "resource_scope": body.resource_scope, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=owner.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        existing = db.scalar(select(CapabilityGrant).where(CapabilityGrant.grantee_user_id == target.id, CapabilityGrant.resource_scope == body.resource_scope, CapabilityGrant.revoked_at.is_(None)))
        if existing:
            raise HTTPException(status_code=409, detail={"code": "ACTIVE_GRANT_EXISTS", "message_for_user": "An active capability grant already exists for this Admin"})
        now = utcnow()
        item = CapabilityGrant(grantor_user_id=owner.id, grantee_user_id=target.id, actions_json=json.dumps(actions), resource_scope=body.resource_scope, reason=body.reason, version=1, created_at=now)
        db.add(item)
        db.flush()
        result = _grant_view(item)
        _remember_idempotency(db, actor_user_id=owner.id, key=key, action="CREATE_CAPABILITY_GRANT", object_type="CAPABILITY_GRANT", object_id=item.id, digest=digest, data=result, status_code=201)
        record_audit(db, actor_user_id=owner.id, action="CAPABILITY_GRANT_CREATE", object_type="CAPABILITY_GRANT", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"grantee_user_id": target.id, "resource_scope": body.resource_scope, "actions": actions})
        record_history(db, actor_user_id=owner.id, object_type="CAPABILITY_GRANT", object_id=item.id, action="CREATE", from_state=None, to_state="ACTIVE", from_version=None, to_version=1, reason=body.reason, request_id=request.state.request_id, metadata={"resource_scope": body.resource_scope, "actions": actions})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.get("/account-review/grants")
    def list_capability_grants(request: Request, db: Session = Depends(_db)):
        _, viewer, _ = _session(request, db)
        if viewer.status != "ACTIVE" or viewer.role not in {"OWNER", "ADMIN"}:
            raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Capability grant access is not available"})
        query = select(CapabilityGrant).order_by(CapabilityGrant.created_at.desc())
        if viewer.role != "OWNER":
            query = query.where(CapabilityGrant.grantee_user_id == viewer.id)
        rows = db.scalars(query).all()
        return ok({"items": [_grant_view(item) for item in rows]}, request.state.request_id, _now_iso())

    @router.get("/account-review/capabilities")
    def account_review_capabilities(request: Request, db: Session = Depends(_db)):
        _, viewer, _ = _session(request, db)
        return ok(_effective_review_capabilities(db, viewer), request.state.request_id, _now_iso())

    @router.post("/account-review/grants/{grant_id}/revoke")
    def revoke_capability_grant(grant_id: str, body: CapabilityGrantRevokeRequest, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match"), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, owner, _ = _require_owner(request, db)
        item = db.get(CapabilityGrant, grant_id)
        if not item:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Capability grant not found"})
        expected = _parse_if_match(if_match)
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "REVOKE_CAPABILITY_GRANT", "grant_id": grant_id, "version": expected, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=owner.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        if expected != item.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Capability grant has changed; reload before retrying"})
        if item.revoked_at:
            raise HTTPException(status_code=409, detail={"code": "GRANT_ALREADY_REVOKED", "message_for_user": "Capability grant is already revoked"})
        old_version = item.version
        item.revoked_at = utcnow()
        item.revoked_by_user_id = owner.id
        item.revoked_reason = body.reason
        item.version += 1
        result = _grant_view(item)
        _remember_idempotency(db, actor_user_id=owner.id, key=key, action="REVOKE_CAPABILITY_GRANT", object_type="CAPABILITY_GRANT", object_id=item.id, digest=digest, data=result)
        record_audit(db, actor_user_id=owner.id, action="CAPABILITY_GRANT_REVOKE", object_type="CAPABILITY_GRANT", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"grantee_user_id": item.grantee_user_id})
        record_history(db, actor_user_id=owner.id, object_type="CAPABILITY_GRANT", object_id=item.id, action="REVOKE", from_state="ACTIVE", to_state="REVOKED", from_version=old_version, to_version=item.version, reason=body.reason, request_id=request.state.request_id)
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.get("/account-review/users")
    def account_review_users(request: Request, db: Session = Depends(_db), status_filter: str | None = None, role: str | None = None, page: int = 1, page_size: int = 25):
        _, reviewer, _ = _session(request, db)
        if reviewer.status != "ACTIVE" or reviewer.role not in {"OWNER", "ADMIN"}:
            raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Account review access is not available"})
        page = max(1, page)
        page_size = min(100, max(1, page_size))
        query = select(User).order_by(User.created_at.desc())
        if status_filter:
            if status_filter not in {"PENDING", "ACTIVE", "REJECTED", "SUSPENDED"}:
                raise HTTPException(status_code=422, detail={"code": "INVALID_STATUS", "message_for_user": "Account status is invalid"})
            query = query.where(User.status == status_filter)
        if role:
            if role not in {"GUEST", "OPERATOR", "ADMIN", "OWNER"}:
                raise HTTPException(status_code=422, detail={"code": "INVALID_ROLE", "message_for_user": "Account role is invalid"})
            query = query.where(User.role == role)
        rows = db.scalars(query.offset((page - 1) * page_size).limit(page_size)).all()
        return ok({"items": [_account_view(item) for item in rows], "page": page, "page_size": page_size, "role_policy": "OWNER_OR_GRANTED_ADMIN_SCOPED", "effective_capabilities": _effective_review_capabilities(db, reviewer)}, request.state.request_id, _now_iso())

    @router.get("/account-review/users/{user_id}")
    def account_review_user(user_id: str, request: Request, db: Session = Depends(_db)):
        _, reviewer, _ = _session(request, db)
        if reviewer.status != "ACTIVE" or reviewer.role not in {"OWNER", "ADMIN"}:
            raise HTTPException(status_code=403, detail={"code": "FORBIDDEN", "message_for_user": "Account review access is not available"})
        user = db.get(User, user_id)
        if not user:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Account not found"})
        history = db.scalars(select(WorkflowHistory).where(WorkflowHistory.object_type == "USER", WorkflowHistory.object_id == user.id).order_by(WorkflowHistory.created_at.desc()).limit(50)).all()
        return ok({"account": _account_view(user), "history": [_history_view(item) for item in history], "effective_capabilities": _effective_review_capabilities(db, reviewer)}, request.state.request_id, _now_iso())

    @router.post("/account-review/users/{user_id}/status")
    def account_review_status(user_id: str, body: AccountStatusRequest, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match"), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, reviewer, _ = _require_account_status_reviewer(request, db)
        target = db.get(User, user_id)
        if not target:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Account not found"})
        if target.id == reviewer.id:
            raise HTTPException(status_code=403, detail={"code": "SELF_REVIEW_FORBIDDEN", "message_for_user": "An account cannot review itself"})
        if reviewer.role == "ADMIN" and (target.role != "GUEST" or target.status != "PENDING" or body.status != "ACTIVE"):
            raise HTTPException(status_code=403, detail={"code": "CAPABILITY_SCOPE_DENIED", "message_for_user": "Admin capability is limited to activating ordinary pending PC users"})
        if body.status == "ACTIVE" and (not target.email_verified_at or not target.credential or not target.credential.totp_active):
            raise HTTPException(status_code=409, detail={"code": "ACCOUNT_NOT_READY", "message_for_user": "Email verification and MFA setup must be complete before activation"})
        expected = _parse_if_match(if_match)
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "ACCOUNT_STATUS_CHANGE", "user_id": target.id, "version": expected, "status": body.status, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=reviewer.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        if expected != target.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Account has changed; reload before retrying"})
        transitions = {"PENDING": {"ACTIVE", "REJECTED"}, "ACTIVE": {"SUSPENDED", "REJECTED"}, "SUSPENDED": {"ACTIVE"}, "REJECTED": set()}
        if body.status not in transitions.get(target.status, set()):
            raise HTTPException(status_code=409, detail={"code": "INVALID_TRANSITION", "message_for_user": "Account status transition is not allowed"})
        old_status = target.status
        old_version = target.version
        now = utcnow()
        target.status = body.status
        target.version += 1
        target.updated_at = now
        if body.status in {"REJECTED", "SUSPENDED"}:
            for session in db.scalars(select(SessionRecord).where(SessionRecord.user_id == target.id, SessionRecord.revoked_at.is_(None))).all():
                session.revoked_at = now
        result = {"account": _account_view(target), "label": "SIMULATED — NOT A FLIGHT PERMIT"}
        _remember_idempotency(db, actor_user_id=reviewer.id, key=key, action="ACCOUNT_STATUS_CHANGE", object_type="USER", object_id=target.id, digest=digest, data=result)
        record_audit(db, actor_user_id=reviewer.id, action="ACCOUNT_STATUS_CHANGE", object_type="USER", object_id=target.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_status": old_status, "to_status": body.status})
        record_history(db, actor_user_id=reviewer.id, object_type="USER", object_id=target.id, action="ACCOUNT_STATUS_CHANGE", from_state=old_status, to_state=body.status, from_version=old_version, to_version=target.version, reason=body.reason, request_id=request.state.request_id)
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.post("/role-elevations")
    def create_role_elevation(body: RoleElevationCreateRequest, request: Request, db: Session = Depends(_db), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, requester, _ = _require_active_user(request, db)
        if requester.role in {"ADMIN", "OWNER"} or (requester.role == "OPERATOR" and body.requested_role != "ADMIN"):
            raise HTTPException(status_code=409, detail={"code": "ROLE_REQUEST_NOT_NEEDED", "message_for_user": "This role request is not available for the current role"})
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "CREATE_ROLE_ELEVATION", "requested_role": body.requested_role, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=requester.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        open_request = db.scalar(select(RoleElevationRequest).where(RoleElevationRequest.requester_user_id == requester.id, RoleElevationRequest.requested_role == body.requested_role, RoleElevationRequest.status == "PENDING"))
        if open_request:
            raise HTTPException(status_code=409, detail={"code": "DUPLICATE_OPEN_REQUEST", "message_for_user": "An open request for this role already exists"})
        now = utcnow()
        item = RoleElevationRequest(requester_user_id=requester.id, requested_role=body.requested_role, status="PENDING", reason=body.reason, version=1, created_at=now, updated_at=now)
        db.add(item)
        db.flush()
        result = _elevation_view(item)
        _remember_idempotency(db, actor_user_id=requester.id, key=key, action="CREATE_ROLE_ELEVATION", object_type="ROLE_ELEVATION", object_id=item.id, digest=digest, data=result, status_code=201)
        record_audit(db, actor_user_id=requester.id, action="ROLE_ELEVATION_CREATE", object_type="ROLE_ELEVATION", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"requested_role": item.requested_role})
        record_history(db, actor_user_id=requester.id, object_type="ROLE_ELEVATION", object_id=item.id, action="CREATE", from_state=None, to_state="PENDING", from_version=None, to_version=1, reason=body.reason, request_id=request.state.request_id, metadata={"requested_role": item.requested_role})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.get("/role-elevations")
    def list_role_elevations(request: Request, db: Session = Depends(_db)):
        _, requester, _ = _session(request, db)
        rows = db.scalars(select(RoleElevationRequest).where(RoleElevationRequest.requester_user_id == requester.id).order_by(RoleElevationRequest.created_at.desc()).limit(100)).all()
        return ok({"items": [_elevation_view(item) for item in rows]}, request.state.request_id, _now_iso())

    @router.get("/role-elevations/review")
    def review_role_elevations(request: Request, db: Session = Depends(_db)):
        _, reviewer, _ = _require_role_reviewer(request, db)
        query = select(RoleElevationRequest).where(RoleElevationRequest.status == "PENDING")
        if reviewer.role == "ADMIN":
            query = query.join(User, User.id == RoleElevationRequest.requester_user_id).where(User.status == "ACTIVE", User.role == "GUEST", RoleElevationRequest.requested_role == "ADMIN")
        rows = db.scalars(query.order_by(RoleElevationRequest.created_at)).all()
        return ok({"items": [_elevation_view(item) for item in rows], "policy": "OWNER_OR_GRANTED_ADMIN_SCOPED", "effective_capabilities": _effective_review_capabilities(db, reviewer)}, request.state.request_id, _now_iso())

    @router.post("/role-elevations/{request_id}/decision")
    def decide_role_elevation(request_id: str, body: RoleElevationDecisionRequest, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match"), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, reviewer, _ = _require_role_reviewer(request, db)
        item = db.get(RoleElevationRequest, request_id)
        if not item:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Role request not found"})
        if item.requester_user_id == reviewer.id:
            raise HTTPException(status_code=403, detail={"code": "SELF_REVIEW_FORBIDDEN", "message_for_user": "A role request cannot review itself"})
        expected = _parse_if_match(if_match)
        if expected != item.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Role request has changed; reload before retrying"})
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "DECIDE_ROLE_ELEVATION", "request_id": request_id, "version": expected, "decision": body.decision, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=reviewer.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        if item.status != "PENDING":
            raise HTTPException(status_code=409, detail={"code": "INVALID_TRANSITION", "message_for_user": "Role request is no longer open"})
        target = db.get(User, item.requester_user_id)
        if not target or target.status != "ACTIVE":
            raise HTTPException(status_code=409, detail={"code": "ACCOUNT_NOT_ACTIVE", "message_for_user": "Requester account is not active"})
        if reviewer.role == "ADMIN" and (body.decision != "APPROVED" or item.requested_role != "ADMIN" or target.role != "GUEST"):
            raise HTTPException(status_code=403, detail={"code": "CAPABILITY_SCOPE_DENIED", "message_for_user": "Admin capability is limited to approving ordinary users to Admin"})
        old_state, old_version = item.status, item.version
        item.status = body.decision
        item.reviewer_user_id = reviewer.id
        item.reviewer_reason = body.reason
        item.reviewed_at = utcnow()
        item.version += 1
        item.updated_at = utcnow()
        if body.decision == "APPROVED":
            if item.requested_role == "OWNER":
                raise HTTPException(status_code=403, detail={"code": "OWNER_ROLE_FORBIDDEN", "message_for_user": "Owner role cannot be granted by this workflow"})
            target.role = item.requested_role
            target.updated_at = utcnow()
        result = _elevation_view(item)
        _remember_idempotency(db, actor_user_id=reviewer.id, key=key, action="DECIDE_ROLE_ELEVATION", object_type="ROLE_ELEVATION", object_id=item.id, digest=digest, data=result)
        record_audit(db, actor_user_id=reviewer.id, action="ROLE_ELEVATION_DECISION", object_type="ROLE_ELEVATION", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_status": old_state, "to_status": item.status, "requested_role": item.requested_role})
        record_history(db, actor_user_id=reviewer.id, object_type="ROLE_ELEVATION", object_id=item.id, action="DECISION", from_state=old_state, to_state=item.status, from_version=old_version, to_version=item.version, reason=body.reason, request_id=request.state.request_id, metadata={"requested_role": item.requested_role})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.post("/simulated/flight-requests", status_code=201)
    def create_flight_request(body: SimulatedFlightCreateRequest, request: Request, db: Session = Depends(_db), settings: Settings = Depends(_settings), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, user, _ = _require_active_user(request, db)
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "CREATE_SIMULATED_FLIGHT", "summary": body.summary, "start": _iso(body.scheduled_start_at), "end": _iso(body.scheduled_end_at), "geometry": body.geometry})
        replay = _idempotency_replay(db, actor_user_id=user.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        try:
            geometry = validate_polygon_geojson(body.geometry, settings.max_zone_bytes)
        except GeometryError as exc:
            raise HTTPException(status_code=422, detail={"code": "INVALID_GEOMETRY", "message_for_user": str(exc)}) from exc
        now = utcnow()
        item = SimulatedFlightRequest(submitter_user_id=user.id, summary=body.summary, scheduled_start_at=body.scheduled_start_at.astimezone(timezone.utc), scheduled_end_at=body.scheduled_end_at.astimezone(timezone.utc), simulated_geometry_json=json.dumps(geometry, separators=(",", ":")), status="DRAFT", version=1, simulated=True, source="USER_SIMULATED", created_at=now, updated_at=now)
        db.add(item)
        db.flush()
        result = _flight_view(item)
        _remember_idempotency(db, actor_user_id=user.id, key=key, action="CREATE_SIMULATED_FLIGHT", object_type="SIMULATED_FLIGHT", object_id=item.id, digest=digest, data=result, status_code=201)
        record_audit(db, actor_user_id=user.id, action="FLIGHT_CREATE", object_type="SIMULATED_FLIGHT", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"to_status": "DRAFT", "simulated": True})
        record_history(db, actor_user_id=user.id, object_type="SIMULATED_FLIGHT", object_id=item.id, action="CREATE", from_state=None, to_state="DRAFT", from_version=None, to_version=1, reason=None, request_id=request.state.request_id, metadata={"simulated": True, "source": item.source})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.get("/simulated/flight-requests")
    def list_flight_requests(request: Request, db: Session = Depends(_db), page: int = 1, page_size: int = 25, status_filter: str | None = None):
        _, user, _ = _require_active_user(request, db)
        page = max(1, page)
        page_size = min(100, max(1, page_size))
        query = select(SimulatedFlightRequest).order_by(SimulatedFlightRequest.updated_at.desc())
        if user.role not in {"OPERATOR", "ADMIN", "OWNER"}:
            query = query.where(SimulatedFlightRequest.submitter_user_id == user.id)
        if status_filter:
            if status_filter not in {"DRAFT", "SUBMITTED", "UNDER_REVIEW", "NEEDS_INFORMATION", "REJECTED", "APPROVED_SIMULATED"}:
                raise HTTPException(status_code=422, detail={"code": "INVALID_STATUS", "message_for_user": "Workflow status is invalid"})
            query = query.where(SimulatedFlightRequest.status == status_filter)
        rows = db.scalars(query.offset((page - 1) * page_size).limit(page_size)).all()
        return ok({"items": [_flight_view(item) for item in rows], "page": page, "page_size": page_size, "label": "SIMULATED — NOT A FLIGHT PERMIT"}, request.state.request_id, _now_iso())

    @router.get("/simulated/flight-requests/{request_id}")
    def get_flight_request(request_id: str, request: Request, db: Session = Depends(_db)):
        _, user, _ = _require_active_user(request, db)
        item = db.get(SimulatedFlightRequest, request_id)
        if not item or (item.submitter_user_id != user.id and user.role not in {"OPERATOR", "ADMIN", "OWNER"}):
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Request not found"})
        return ok(_flight_view(item), request.state.request_id, _now_iso())

    @router.patch("/simulated/flight-requests/{request_id}")
    def edit_flight_request(request_id: str, body: SimulatedFlightCreateRequest, request: Request, db: Session = Depends(_db), settings: Settings = Depends(_settings), if_match: str | None = Header(default=None, alias="If-Match")):
        _, user, _ = _require_active_user(request, db)
        item = db.get(SimulatedFlightRequest, request_id)
        if not item or item.submitter_user_id != user.id:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Request not found"})
        expected = _parse_if_match(if_match)
        if expected != item.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Request has changed; reload before retrying"})
        if item.status not in {"DRAFT", "NEEDS_INFORMATION"}:
            raise HTTPException(status_code=409, detail={"code": "INVALID_TRANSITION", "message_for_user": "Only draft or information-requested items can be edited"})
        try:
            geometry = validate_polygon_geojson(body.geometry, settings.max_zone_bytes)
        except GeometryError as exc:
            raise HTTPException(status_code=422, detail={"code": "INVALID_GEOMETRY", "message_for_user": str(exc)}) from exc
        old_version = item.version
        item.summary = body.summary
        item.scheduled_start_at = body.scheduled_start_at.astimezone(timezone.utc)
        item.scheduled_end_at = body.scheduled_end_at.astimezone(timezone.utc)
        item.simulated_geometry_json = json.dumps(geometry, separators=(",", ":"))
        item.version += 1
        item.updated_at = utcnow()
        result = _flight_view(item)
        record_audit(db, actor_user_id=user.id, action="FLIGHT_EDIT", object_type="SIMULATED_FLIGHT", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_version": old_version, "to_version": item.version, "simulated": True})
        record_history(db, actor_user_id=user.id, object_type="SIMULATED_FLIGHT", object_id=item.id, action="EDIT", from_state=item.status, to_state=item.status, from_version=old_version, to_version=item.version, reason=None, request_id=request.state.request_id, metadata={"simulated": True})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.post("/simulated/flight-requests/{request_id}/submit")
    def submit_flight_request(request_id: str, body: SimulatedFlightActionRequest, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match"), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, user, _ = _require_active_user(request, db)
        item = db.get(SimulatedFlightRequest, request_id)
        if not item or item.submitter_user_id != user.id:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Request not found"})
        expected = _parse_if_match(if_match)
        if expected != item.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Request has changed; reload before retrying"})
        if item.status not in {"DRAFT", "NEEDS_INFORMATION"}:
            raise HTTPException(status_code=409, detail={"code": "INVALID_TRANSITION", "message_for_user": "Request cannot be submitted from this state"})
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "SUBMIT_SIMULATED_FLIGHT", "request_id": request_id, "version": expected, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=user.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        old_state, old_version = item.status, item.version
        item.status = "SUBMITTED"
        item.version += 1
        item.updated_at = utcnow()
        result = _flight_view(item)
        _remember_idempotency(db, actor_user_id=user.id, key=key, action="SUBMIT_SIMULATED_FLIGHT", object_type="SIMULATED_FLIGHT", object_id=item.id, digest=digest, data=result)
        record_audit(db, actor_user_id=user.id, action="FLIGHT_SUBMIT", object_type="SIMULATED_FLIGHT", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_status": old_state, "to_status": item.status, "simulated": True})
        record_history(db, actor_user_id=user.id, object_type="SIMULATED_FLIGHT", object_id=item.id, action="SUBMIT", from_state=old_state, to_state=item.status, from_version=old_version, to_version=item.version, reason=body.reason, request_id=request.state.request_id, metadata={"simulated": True})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.post("/simulated/flight-requests/{request_id}/review")
    def review_flight_request(request_id: str, body: SimulatedFlightActionRequest, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match"), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, reviewer, _ = _require_workflow_reviewer(request, db)
        item = db.get(SimulatedFlightRequest, request_id)
        if not item:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Request not found"})
        expected = _parse_if_match(if_match)
        if expected != item.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Request has changed; reload before retrying"})
        if item.status != "SUBMITTED":
            raise HTTPException(status_code=409, detail={"code": "INVALID_TRANSITION", "message_for_user": "Only submitted requests can enter review"})
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "START_REVIEW", "request_id": request_id, "version": expected, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=reviewer.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        old_version = item.version
        item.status = "UNDER_REVIEW"
        item.version += 1
        item.updated_at = utcnow()
        result = _flight_view(item)
        _remember_idempotency(db, actor_user_id=reviewer.id, key=key, action="START_REVIEW", object_type="SIMULATED_FLIGHT", object_id=item.id, digest=digest, data=result)
        record_audit(db, actor_user_id=reviewer.id, action="FLIGHT_REVIEW_START", object_type="SIMULATED_FLIGHT", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_status": "SUBMITTED", "to_status": item.status, "simulated": True})
        record_history(db, actor_user_id=reviewer.id, object_type="SIMULATED_FLIGHT", object_id=item.id, action="REVIEW_START", from_state="SUBMITTED", to_state=item.status, from_version=old_version, to_version=item.version, reason=body.reason, request_id=request.state.request_id, metadata={"simulated": True})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.post("/simulated/flight-requests/{request_id}/decision")
    def decide_flight_request(request_id: str, body: SimulatedFlightDecisionRequest, request: Request, db: Session = Depends(_db), if_match: str | None = Header(default=None, alias="If-Match"), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
        _, reviewer, _ = _require_workflow_reviewer(request, db)
        item = db.get(SimulatedFlightRequest, request_id)
        if not item:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "Request not found"})
        if item.submitter_user_id == reviewer.id:
            raise HTTPException(status_code=403, detail={"code": "SELF_REVIEW_FORBIDDEN", "message_for_user": "A submitter cannot review its own request"})
        expected = _parse_if_match(if_match)
        if expected != item.version:
            raise HTTPException(status_code=409, detail={"code": "VERSION_CONFLICT", "message_for_user": "Request has changed; reload before retrying"})
        if item.status != "UNDER_REVIEW":
            raise HTTPException(status_code=409, detail={"code": "INVALID_TRANSITION", "message_for_user": "Only requests under review can receive a decision"})
        key = _require_idempotency_key(idempotency_key)
        digest = payload_digest({"action": "DECIDE_SIMULATED_FLIGHT", "request_id": request_id, "version": expected, "decision": body.decision, "reason": body.reason})
        replay = _idempotency_replay(db, actor_user_id=reviewer.id, key=key, digest=digest)
        if replay:
            return ok(json.loads(replay.response_json), request.state.request_id, _now_iso())
        old_state, old_version = item.status, item.version
        item.status = body.decision
        item.version += 1
        item.updated_at = utcnow()
        result = _flight_view(item)
        _remember_idempotency(db, actor_user_id=reviewer.id, key=key, action="DECIDE_SIMULATED_FLIGHT", object_type="SIMULATED_FLIGHT", object_id=item.id, digest=digest, data=result)
        record_audit(db, actor_user_id=reviewer.id, action="FLIGHT_DECISION", object_type="SIMULATED_FLIGHT", object_id=item.id, outcome="SUCCESS", request_id=request.state.request_id, metadata={"from_status": old_state, "to_status": item.status, "simulated": True})
        record_history(db, actor_user_id=reviewer.id, object_type="SIMULATED_FLIGHT", object_id=item.id, action="DECISION", from_state=old_state, to_state=item.status, from_version=old_version, to_version=item.version, reason=body.reason, request_id=request.state.request_id, metadata={"simulated": True, "label": "SIMULATED — NOT A FLIGHT PERMIT"})
        db.commit()
        return ok(result, request.state.request_id, _now_iso())

    @router.get("/history/{object_type}/{object_id}")
    def history(object_type: str, object_id: str, request: Request, db: Session = Depends(_db), page: int = 1, page_size: int = 50):
        _, user, _ = _session(request, db)
        allowed = False
        if object_type == "USER":
            allowed = user.role in {"OWNER", "ADMIN"} and user.status == "ACTIVE"
        elif object_type == "ROLE_ELEVATION":
            item = db.get(RoleElevationRequest, object_id)
            allowed = bool(item and (item.requester_user_id == user.id or (user.role == "OWNER" and user.status == "ACTIVE")))
        elif object_type == "SIMULATED_FLIGHT":
            item = db.get(SimulatedFlightRequest, object_id)
            allowed = bool(item and (item.submitter_user_id == user.id or (user.role in {"OPERATOR", "ADMIN", "OWNER"} and user.status == "ACTIVE")))
        if not allowed:
            raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message_for_user": "History not found"})
        page = max(1, page)
        page_size = min(100, max(1, page_size))
        rows = db.scalars(select(WorkflowHistory).where(WorkflowHistory.object_type == object_type, WorkflowHistory.object_id == object_id).order_by(WorkflowHistory.created_at.desc()).offset((page - 1) * page_size).limit(page_size)).all()
        return ok({"items": [_history_view(item) for item in rows], "page": page, "page_size": page_size, "redacted": True}, request.state.request_id, _now_iso())

    @router.get("/audit")
    def audit_events(request: Request, db: Session = Depends(_db), object_type: str | None = None, object_id: str | None = None, page: int = 1, page_size: int = 50):
        _require_owner(request, db)
        page = max(1, page)
        page_size = min(100, max(1, page_size))
        query = select(AuditEvent).order_by(AuditEvent.created_at.desc())
        if object_type:
            query = query.where(AuditEvent.object_type == object_type)
        if object_id:
            query = query.where(AuditEvent.object_id == object_id)
        rows = db.scalars(query.offset((page - 1) * page_size).limit(page_size)).all()
        data = [{"id": item.id, "actor_user_id": item.actor_user_id, "action": item.action, "object_type": item.object_type, "object_id": item.object_id, "outcome": item.outcome, "request_id": item.request_id, "metadata": json.loads(item.metadata_redacted or "{}"), "created_at": _iso(item.created_at)} for item in rows]
        return ok({"items": data, "page": page, "page_size": page_size, "redacted": True}, request.state.request_id, _now_iso())

    @router.get("/pi/v1/map")
    def fake_pi_map(request: Request, db: Session = Depends(_db), fake_pi_client: str | None = Header(default=None, alias="X-Fake-Pi-Client"), offline: bool = False):
        _require_active_user(request, db)
        if fake_pi_client != "scope02-test-client":
            raise HTTPException(status_code=401, detail={"code": "PI_CLIENT_AUTH_REQUIRED", "message_for_user": "Fake Pi client identity is required"})
        rows = db.scalars(select(Zone).where(Zone.visibility == "PUBLIC", Zone.deleted_at.is_(None)).order_by(Zone.name)).all()
        return ok({"adapter_version": "v1", "simulated": True, "label": "SIMULATED — NOT A FLIGHT PERMIT", "source": "TEST_FIXTURE", "sync_state": "UNSYNCED" if offline else "SYNCED", "stale": offline, "items": [{"id": z.id, "name": z.name, "geometry": json.loads(z.geometry_json), "simulated": True, "source": "TEST_FIXTURE"} for z in rows]}, request.state.request_id, _now_iso())

    @router.get("/pi/v1/status")
    def fake_pi_status(request: Request, db: Session = Depends(_db), fake_pi_client: str | None = Header(default=None, alias="X-Fake-Pi-Client"), offline: bool = False):
        _, user, _ = _require_active_user(request, db)
        if fake_pi_client != "scope02-test-client":
            raise HTTPException(status_code=401, detail={"code": "PI_CLIENT_AUTH_REQUIRED", "message_for_user": "Fake Pi client identity is required"})
        query = select(SimulatedFlightRequest).order_by(SimulatedFlightRequest.updated_at.desc())
        if user.role not in {"OPERATOR", "ADMIN", "OWNER"}:
            query = query.where(SimulatedFlightRequest.submitter_user_id == user.id)
        rows = db.scalars(query.limit(100)).all()
        return ok({"adapter_version": "v1", "simulated": True, "label": "SIMULATED — NOT A FLIGHT PERMIT", "sync_state": "UNSYNCED" if offline else "SYNCED", "stale": offline, "central_server_reachable": not offline, "items": [{"id": item.id, "status": item.status, "simulated": True, "label": "SIMULATED — NOT A FLIGHT PERMIT", "source": item.source, "version": item.version} for item in rows]}, request.state.request_id, _now_iso())

    return router
