from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator


class RegisterRequest(BaseModel):
    display_name: str = Field(min_length=1, max_length=160)
    email: EmailStr
    password: str = Field(min_length=12, max_length=128)
    password_confirm: str = Field(min_length=12, max_length=128)
    terms_version: str = Field(min_length=1, max_length=64)

    @model_validator(mode="after")
    def passwords_match(self):
        if self.password != self.password_confirm:
            raise ValueError("passwords do not match")
        return self


class CodeRequest(BaseModel):
    challenge_id: str = Field(min_length=1, max_length=64)
    code: str = Field(pattern=r"^\d{6}$")


class EnrollmentCodeRequest(BaseModel):
    code: str = Field(pattern=r"^\d{6}$")


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)
    terms_version: str = Field(min_length=1, max_length=64)


class RecoveryRequest(BaseModel):
    code: str = Field(min_length=8, max_length=32)


class ZoneCreateRequest(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    geometry: dict[str, Any]
    visibility: Literal["PUBLIC", "INTERNAL"]
    classification: Literal["DEMO", "INTERNAL_RESEARCH"]
    source_id: str = Field(min_length=1, max_length=64)

    @field_validator("name")
    @classmethod
    def strip_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("name must not be empty")
        return value


class ZoneUpdateRequest(ZoneCreateRequest):
    version: int = Field(ge=1)


class PublicZone(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    geometry: dict[str, Any]
    visibility: Literal["PUBLIC"]
    classification: Literal["DEMO"]
    version: int
    retrieved_at: str


class InternalZone(PublicZone):
    visibility: Literal["PUBLIC", "INTERNAL"]
    classification: Literal["DEMO", "INTERNAL_RESEARCH"]
    source_id: str


class AccountStatusRequest(BaseModel):
    status: Literal["ACTIVE", "REJECTED", "SUSPENDED"]
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("reason")
    @classmethod
    def strip_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("reason must not be empty")
        return value


class CapabilityGrantCreateRequest(BaseModel):
    grantee_user_id: str = Field(min_length=1, max_length=64)
    actions: list[Literal["ACCOUNT_APPROVE", "ADMIN_ROLE_APPROVE"]] = Field(min_length=1, max_length=2)
    resource_scope: Literal["PC_GUEST"]
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("actions")
    @classmethod
    def unique_actions(cls, value: list[str]) -> list[str]:
        if len(set(value)) != len(value):
            raise ValueError("actions must be unique")
        return value

    @field_validator("reason")
    @classmethod
    def strip_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("reason must not be empty")
        return value


class CapabilityGrantRevokeRequest(BaseModel):
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("reason")
    @classmethod
    def strip_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("reason must not be empty")
        return value


class RoleElevationCreateRequest(BaseModel):
    requested_role: Literal["OPERATOR", "ADMIN"]
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("reason")
    @classmethod
    def strip_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("reason must not be empty")
        return value


class RoleElevationDecisionRequest(BaseModel):
    decision: Literal["APPROVED", "REJECTED"]
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("reason")
    @classmethod
    def strip_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("reason must not be empty")
        return value


class SimulatedFlightCreateRequest(BaseModel):
    summary: str = Field(min_length=3, max_length=240)
    scheduled_start_at: datetime
    scheduled_end_at: datetime
    geometry: dict[str, Any]

    @field_validator("summary")
    @classmethod
    def strip_summary(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("summary must not be empty")
        return value

    @model_validator(mode="after")
    def validate_schedule(self):
        if self.scheduled_start_at.tzinfo is None or self.scheduled_end_at.tzinfo is None:
            raise ValueError("scheduled times must include a timezone")
        if self.scheduled_end_at <= self.scheduled_start_at:
            raise ValueError("scheduled_end_at must be after scheduled_start_at")
        return self


class SimulatedFlightActionRequest(BaseModel):
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("reason")
    @classmethod
    def strip_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("reason must not be empty")
        return value


class SimulatedFlightDecisionRequest(BaseModel):
    decision: Literal["NEEDS_INFORMATION", "REJECTED", "APPROVED_SIMULATED"]
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("reason")
    @classmethod
    def strip_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("reason must not be empty")
        return value


def ok(data: Any, request_id: str, observed_at: str) -> dict[str, Any]:
    return {"schema_version": "v1", "request_id": request_id, "data": data, "error": None, "observed_at": observed_at}
