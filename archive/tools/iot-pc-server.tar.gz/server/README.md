# PC Server

This directory is the canonical FastAPI application for the PC control plane.
Start with the repository [README](../README.md), then use the scope documents
under `docs/scopes/` for behavior and acceptance criteria.

It is simulation-only: it does not control motors, arm/disarm a vehicle, issue
flight permits or authorize real-world operations.

## Setup

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r server/requirements.lock
export SESSION_SECRET="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(32))')"
export COOKIE_SECURE=true
.venv/bin/alembic -c server/alembic.ini upgrade head
```

For local API tests without HTTPS, tests set `COOKIE_SECURE=false` in an isolated process. Do not change the product default for browser deployment; use trusted local HTTPS for browser E2E.

## Run

```bash
export SESSION_SECRET="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(32))')"
.venv/bin/uvicorn server.app.main:app --host 127.0.0.1 --port 8765
npm --prefix frontend run dev
```

Port `7070` is intentionally not used. Both servers bind loopback only. Vite proxies `/api` to `127.0.0.1:8765`; CORS remains an explicit allowlist.

## Owner bootstrap

```bash
export FAKE_MAIL_OUTBOX="$(mktemp)"
.venv/bin/python -m server.cli bootstrap-owner --name "Local Owner" --email owner@example.test
```

The command creates a `PENDING` owner record and a verification challenge in the explicitly configured local fake-mail outbox; it never prints a password, OTP or TOTP seed. Run the API with the same `FAKE_MAIL_OUTBOX` for the approved local flow.

SCOPE-02 account review is backend-authoritative. `ADMIN` can inspect account records; only an active `OWNER` can change another account's status. The first Owner is not activated through HTTP. After the local verification/MFA flow, an operator may use the explicit local procedure:

```bash
.venv/bin/python -m server.cli activate-bootstrap-owner --email owner@example.test --confirm "ACTIVATE FIRST OWNER"
```

It requires the existing Owner password and current TOTP code through hidden prompts, and records a redacted audit/history event. It is not a normal account self-approval path.

SCOPE-02 also provides simulated workflow routes under `/api/v1/simulated/flight-requests`, role elevation under `/api/v1/role-elevations`, redacted history/audit queries, and read-only fake Pi endpoints under `/api/v1/pi/v1/`. Every workflow result is labeled `SIMULATED — NOT A FLIGHT PERMIT`; the fake Pi identity is only `X-Fake-Pi-Client: scope02-test-client` in local tests, and `offline=true` returns an explicit stale/unsynced state without external calls.
