from __future__ import annotations

import argparse
import getpass
import os
import uuid

import pyotp
from sqlalchemy import select

from server.app.config import load_settings
from server.app.db import make_engine, make_session_factory
from server.app.mail import FakeEmailSender
from server.app.models import Credential, User
from server.app.security import decrypt_secret, hash_password, normalize_email, totp_at, utcnow, verify_password
from server.app.services import create_email_code, record_audit, record_history


def bootstrap_owner(args: argparse.Namespace) -> int:
    settings = load_settings()
    if not settings.fake_mail_outbox:
        raise SystemExit("FAKE_MAIL_OUTBOX is required for local owner bootstrap; no verification factor is bypassed")
    engine = make_engine(settings.database_url)
    factory = make_session_factory(engine)
    mail = FakeEmailSender(settings.fake_mail_outbox)
    email = normalize_email(args.email)
    password = getpass.getpass("Owner password (hidden): ")
    confirm = getpass.getpass("Repeat owner password (hidden): ")
    if password != confirm or len(password) < 12:
        raise SystemExit("passwords must match and be at least 12 characters")
    with factory() as db:
        if db.scalar(select(User).where(User.role == "OWNER")):
            raise SystemExit("owner bootstrap has already been used")
        now = utcnow()
        user = User(display_name=args.name, email_normalized=email, status="PENDING", role="OWNER", created_at=now, updated_at=now)
        user.credential = Credential(password_hash=hash_password(password), created_at=now, updated_at=now)
        db.add(user)
        db.flush()
        create_email_code(db, settings, mail, user_id=user.id, email=email, purpose="VERIFY_EMAIL")
        db.commit()
    engine.dispose()
    print(f"Owner record created in PENDING state; fake verification mail written to {settings.fake_mail_outbox}.")
    print("Complete email verification and MFA through the approved local flow; account approval remains outside SCOPE-01.")
    return 0


def activate_bootstrap_owner(args: argparse.Namespace) -> int:
    if args.confirm != "ACTIVATE FIRST OWNER":
        raise SystemExit("exact confirmation phrase is required")
    settings = load_settings()
    engine = make_engine(settings.database_url)
    factory = make_session_factory(engine)
    email = normalize_email(args.email)
    password = getpass.getpass("Existing owner password (hidden): ")
    totp_code = getpass.getpass("Current owner TOTP code (hidden): ")
    request_id = f"cli-{uuid.uuid4()}"
    with factory() as db:
        owner = db.scalar(select(User).where(User.email_normalized == email, User.role == "OWNER"))
        if not owner or owner.status != "PENDING":
            raise SystemExit("no pending bootstrap owner found")
        if not owner.email_verified_at or not owner.credential or not owner.credential.totp_active:
            raise SystemExit("owner email verification and MFA must be complete first")
        if not verify_password(owner.credential.password_hash, password):
            raise SystemExit("owner password verification failed")
        secret = decrypt_secret(settings.session_secret, owner.credential.totp_secret_encrypted or "")
        valid, _ = totp_at(secret, totp_code)
        if not valid:
            raise SystemExit("owner TOTP verification failed")
        old_version = owner.version
        owner.status = "ACTIVE"
        owner.version += 1
        owner.updated_at = utcnow()
        now = utcnow()
        record_audit(db, actor_user_id=None, action="LOCAL_BOOTSTRAP_ACTIVATION", object_type="USER", object_id=owner.id, outcome="SUCCESS", request_id=request_id, metadata={"from_status": "PENDING", "to_status": "ACTIVE", "operator_confirmation": True})
        record_history(db, actor_user_id=None, object_type="USER", object_id=owner.id, action="LOCAL_BOOTSTRAP_ACTIVATION", from_state="PENDING", to_state="ACTIVE", from_version=old_version, to_version=owner.version, reason="Local operator confirmation and MFA", request_id=request_id, metadata={"operator_confirmation": True})
        db.commit()
    engine.dispose()
    print("Bootstrap owner activated through the explicit local operator procedure.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Local-only PC administration")
    sub = parser.add_subparsers(dest="command", required=True)
    owner = sub.add_parser("bootstrap-owner")
    owner.add_argument("--name", required=True)
    owner.add_argument("--email", required=True)
    owner.set_defaults(func=bootstrap_owner)
    activate = sub.add_parser("activate-bootstrap-owner")
    activate.add_argument("--email", required=True)
    activate.add_argument("--confirm", required=True)
    activate.set_defaults(func=activate_bootstrap_owner)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
